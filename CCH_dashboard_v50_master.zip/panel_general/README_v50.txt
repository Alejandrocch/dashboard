C&CH DASHBOARDS — v50 (master)
Fecha del paquete: 04/02/2026

Incluye:
- index.html
- styles.css
- app.js
- README_v50.txt
- CCH_v45_codigo_comentado.pdf (referencia)
- assets/logo-white.png (logo sobre fondo oscuro)
- assets/logo-black.png (logo sobre fondo claro)

Notas:
- Tema Dark/Light (botón arriba a la derecha). Recuerda la elección en el navegador.
- Ancho maximizado (wrap 1680px, padding lateral bajo).
- Tipografía mayor y separación real entre líneas:
  - Listas: gap 10px
  - Tablas: border-spacing 0 10px
- Modal popup: clic en item/fila abre el detalle completo (observaciones incluidas).
- Panel central 3 columnas (RFQs / Ofertas / Pedidos) + pestañas detalle.

HOSTINGER (deploy rápido "online")
1) En Hostinger → Administrador de archivos → public_html/
2) Crea una carpeta: panel_general/
3) Sube TODO el contenido de este ZIP dentro de public_html/panel_general/
4) Accede: https://TU_DOMINIO/panel_general/

IMPORTANTE (RFQs / emails en vivo)
- Este ZIP es 100% front-end (estático). No metas credenciales en JS/HTML.
- Para leer IMAP en vivo necesitas un backend (Node) que use tu .env y exponga un endpoint (p.ej. /api/rfqs).
- Cuando me pases los .env, te preparo el backend y lo dejamos listo para Hostinger (si tu plan permite Node; si no, lo montamos en un VPS o en un subservicio).

Siguiente paso (tras tu OK visual): activar test IMAP real para RFQs.
