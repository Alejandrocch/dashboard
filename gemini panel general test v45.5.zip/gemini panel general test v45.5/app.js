/* app.js — C&CH DASHBOARDS v45.4
   - Carga Ofertas/Pedidos desde CSV (mapeo tolerante)
   - Filtros globales (serie, comercial, fecha, texto)
   - Panel central 3 columnas + paneles detalle por pestaña
   - Modal popup de detalle para leer observaciones completas
*/
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

// v45.4: filtros globales (B) + parser CSV robusto (multilínea)
const state = {
  ofertasRaw:[],
  pedidosRaw:[],
  rfqs:[],
  // v45.4: orden por defecto SIEMPRE por fecha más reciente (DESC)
  // con toggle (▼ / ▲) para invertir a más antiguas primero.
  sort:{ rfqs:'desc', ofertas:'desc', pedidos:'desc' },
  emailView:'rfq', // rfq | oferta | pedido | spam | todos
  filters:{
    serie:'',
    comercial:'',
    estadoOfertas:'',
    visado:'',
    estadoPedidos:'',
    desde:'',
    hasta:'',
    q:''
  }
};

// === CARGA EMAILS REALES DESDE IMAP (emails_inbox.json) ===
fetch('./emails_inbox.json')
  .then(r => {
    if (!r.ok) throw new Error('No se pudo cargar emails_inbox.json');
    return r.json();
  })
  .then(data => {
    console.log('Emails IMAP cargados:', data.length);
    state.rfqs = data;
    renderRFQs();   // ← usa el render actual
  })
  .catch(err => {
    console.error('Error cargando emails_inbox.json', err);
  });


function sortByFecha(rows, order='desc'){
  return rows.slice().sort((a,b)=>{
    const da = parseDateToISO(a.fecha)||'';
    const db = parseDateToISO(b.fecha)||'';
    return (order==='asc') ? da.localeCompare(db) : db.localeCompare(da);
  });
}

function setSortIcon(kind){
  const icon = (state.sort[kind] === 'asc') ? '▲' : '▼';
  const ids = {
    rfqs: ['#btnSortRFQs','#btnSortRFQs2'],
    ofertas: ['#btnSortOfertas','#btnSortOfertas2'],
    pedidos: ['#btnSortPedidos','#btnSortPedidos2'],
  }[kind] || [];
  for(const sel of ids){
    const el = $(sel);
    if(el) el.textContent = icon;
  }
}

function toggleSort(kind){
  state.sort[kind] = (state.sort[kind] === 'asc') ? 'desc' : 'asc';
  setSortIcon(kind);
  renderAll();
}

function norm(s){ return String(s??'').trim(); }
function keyify(s){ return norm(s).toLowerCase().replace(/\s+/g,''); }
function toNumber(v){
  if(v==null) return 0;
  const s = String(v).trim();
  if(!s) return 0;
  const cleaned = s.replace(/\./g,'').replace(',', '.').replace(/[^0-9.-]/g,'');
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}
function fmtEUR(n){
  try{ return new Intl.NumberFormat('es-ES',{style:'currency',currency:'EUR'}).format(n||0); }
  catch{ return (n||0).toFixed(2)+' €'; }
}
function fmtDate(d){
  if(!d) return '';
  const s = String(d).trim();
  if(/\d{2}\/\d{2}\/\d{4}/.test(s)) return s;
  const dt = new Date(s);
  if(!isNaN(dt.getTime())) return dt.toLocaleString('es-ES');
  return s;
}
function parseDateToISO(s){
  if(!s) return '';
  const t = String(s).trim();
  const m = t.match(/(\d{2})\/(\d{2})\/(\d{4})/);
  if(m) return `${m[3]}-${m[2]}-${m[1]}`;
  const dt = new Date(t);
  if(!isNaN(dt.getTime())) return dt.toISOString().slice(0,10);
  return '';
}
function escapeHtml(s){
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function short(s, n=64){ const t=norm(s); return t.length>n ? t.slice(0,n-1)+'…' : t; }
function sum(arr, fn){ return arr.reduce((a,x)=>a+(fn(x)||0), 0); }
function countWhere(arr, pred){ return arr.reduce((a,x)=>a+(pred(x)?1:0), 0); }

const mapOfertas = {
  serie:['serie'],
  numOferta:['numoferta','nºoferta','nooferta','numerooferta','oferta'],
  fecha:['fecha','fechaemision','fechaemisión'],
  idCliente:['idcliente','codcliente','clienteid'],
  cliente:['cliente'],
  razon:['razonsocial','razónsocial','razonsoc'],
  comercial:['comercial','agente','vendedor'],
  estado:['estadodescrp','estadodescrip','estado','estadodescripcion'],
  visado:['visado'],
  obs:['observaciones','observacion','obs'],
  totalIva:['totaliva','importe','importeiva','total'],
  idOferta:['idoferta','id oferta','id_oferta']
};
const mapPedidos = {
  idPedido:['idpedido','id pedido','id_pedido'],
  serie:['serie'],
  numPedido:['numeropedido','númeropedido','nºpedido','nopedido','pedido','numeropedido'],
  fecha:['fecha','fechapedido','fecha pedido'],
  cliente:['cliente'],
  idCliente:['idcliente','codcliente','clienteid'],
  razon:['razonsocial','razónsocial'],
  desc:['descripcionpedido','descripciónpedido','descripcion','descripción'],
  estado:['estado'],
  totalIva:['totaliva','importe','total'],
  obs:['observaciones','observacion','obs']
};
function pickCol(headerMap, cols){
  const colKeys = cols.map(c=>keyify(c));
  const out = {};
  for(const [field, aliases] of Object.entries(headerMap)){
    let idx = -1;
    for(const a of aliases){
      idx = colKeys.indexOf(keyify(a));
      if(idx>=0) break;
    }
    out[field]=idx;
  }
  return out;
}

function parseCSV(text){
  // Parser robusto:
  // - soporta campos multilínea entrecomillados
  // - soporta comillas escapadas ("")
  // - detecta separador (;) o (,)
  // - tolera \r\n / \n
  const src = String(text ?? '').replace(/\r\n/g,'\n').replace(/\r/g,'\n');
  if(!src.trim()) return {cols:[], rows:[]};

  const headerLine = readFirstRecord(src);
  const sep = detectSep(headerLine);
  const all = parseAll(src, sep);
  const cols = (all[0] || []).map(c=>norm(c));
  const rows = all.slice(1).filter(r=>r.some(c=>String(c??'').trim().length));
  return { cols, rows };

  function readFirstRecord(s){
    let inQ=false; let out='';
    for(let i=0;i<s.length;i++){
      const ch=s[i];
      if(ch==='"'){
        if(inQ && s[i+1]==='"'){ out+='"'; i++; }
        else inQ=!inQ;
        continue;
      }
      if(ch==='\n' && !inQ) break;
      out+=ch;
    }
    return out;
  }

  function detectSep(line){
    // cuenta separadores fuera de comillas
    let inQ=false, semi=0, comma=0;
    for(let i=0;i<line.length;i++){
      const ch=line[i];
      if(ch==='"'){
        if(inQ && line[i+1]==='"') i++;
        else inQ=!inQ;
        continue;
      }
      if(!inQ){
        if(ch===';') semi++;
        else if(ch===',') comma++;
      }
    }
    return (semi>=comma) ? ';' : ',';
  }

  function parseAll(s, sep){
    const rows=[];
    let row=[];
    let cur='';
    let inQ=false;

    for(let i=0;i<s.length;i++){
      const ch=s[i];

      if(ch==='"'){
        if(inQ && s[i+1]==='"'){ cur+='"'; i++; }
        else inQ=!inQ;
        continue;
      }

      if(ch===sep && !inQ){
        row.push(cur);
        cur='';
        continue;
      }

      if(ch==='\n' && !inQ){
        row.push(cur);
        cur='';
        // evitar fila vacía espuria
        if(row.length>1 || row[0]?.trim()) rows.push(row);
        row=[];
        continue;
      }

      cur+=ch;
    }

    // último campo
    row.push(cur);
    if(row.length>1 || row[0]?.trim()) rows.push(row);
    return rows;
  }
}

function badgeFromEstado(estado){
  const e = norm(estado).toLowerCase();
  if(/acept|final|complet/.test(e)) return { text: estado||'OK', kind:'ok' };
  if(/pend|eval|curso|prepar|generad/.test(e)) return { text: estado||'En curso', kind:'warn' };
  if(/rech/.test(e)) return { text: estado||'Rechazada', kind:'bad' };
  return { text: estado||'N/D', kind:'' };
}


function stripHtml(html){
  const t = String(html||'');
  return t.replace(/<style[\s\S]*?<\/style>/gi,'')
          .replace(/<script[\s\S]*?<\/script>/gi,'')
          .replace(/<[^>]+>/g,' ')
          .replace(/\s+/g,' ')
          .trim();
}

function getEmailBody(raw){
  if(!raw) return '';
  const cand = [raw.body, raw.text, raw.textPlain, raw.plain, raw.snippet, raw.preview, raw.content, raw.html, raw.textHtml];
  for(const c of cand){
    const v = (c==null) ? '' : String(c);
    if(v && v.trim()) return (/<[a-z][\s\S]*>/i.test(v) ? stripHtml(v) : v).trim();
  }
  return '';
}

function mailtoLink(to, subject, body){
  const s = encodeURIComponent(subject||'');
  const b = encodeURIComponent(body||'');
  return `mailto:${encodeURIComponent(to||'')}?subject=${s}&body=${b}`;
}

function classifyEmail(raw){
  const from = norm(raw?.from || raw?.email || raw?.sender || raw?.senderEmail || '').toLowerCase();
  const subj = norm(raw?.subject || raw?.asunto || '').toLowerCase();
  const body = norm(getEmailBody(raw)).toLowerCase();

  const isSpam = (
    /unsubscribe|newsletter|promoc|marketing|oferta\s+especial|campaña/.test(subj+" "+body) ||
    /noreply|no-reply|notifications|notification|mailer|hubspot|mailchimp/.test(from) ||
    /@gmail\.com$/.test(from) // a tu criterio: Gmail a SPAM por defecto
  );
  if(isSpam) return 'spam';

  // Clasificación muy simple (ajustaremos con ejemplos reales)
  if(/pedido|order|\bpo\b/.test(subj+" "+body)) return 'pedido';
  if(/oferta|presupuesto|quote|cotiz/.test(subj+" "+body)) return 'oferta';
  return 'rfq';
}

function renderRFQModal(r){
  const wrap=document.createElement('div');

  const buttons=document.createElement('div');
  buttons.style.display='flex';
  buttons.style.gap='10px';
  buttons.style.flexWrap='wrap';
  buttons.style.marginBottom='12px';

  const btnReply=document.createElement('a');
  btnReply.className='btn';
  btnReply.textContent='Responder (Outlook)';
  const replyBody = `Hola,

Respondo a tu email:

---
${(r.cuerpo||'').slice(0,2000)}
---
`;
  btnReply.href = mailtoLink(r.email, 'RE: '+(r.asunto||''), replyBody);
  buttons.appendChild(btnReply);

  const btnCopy=document.createElement('button');
  btnCopy.className='btn btnGhost';
  btnCopy.textContent='Copiar email';
  btnCopy.addEventListener('click', async ()=>{
    try{ await navigator.clipboard.writeText(r.email||''); alert('Email copiado'); }
    catch{ alert(r.email||''); }
  });
  buttons.appendChild(btnCopy);

  wrap.appendChild(buttons);

  wrap.appendChild(renderKV({
    'Empresa':r.empresa,
    'Fecha':r.fecha,
    'Estado':r.estado,
    'Tipo':(r.tipo||'rfq').toUpperCase(),
    'Email':r.email,
    'Teléfono':r.tel||'—',
    'Asunto':r.asunto
  }));

  const bodyTitle=document.createElement('div');
  bodyTitle.className='muted';
  bodyTitle.style.margin='12px 0 6px';
  bodyTitle.textContent='Cuerpo del email';
  wrap.appendChild(bodyTitle);

  const pre=document.createElement('pre');
  pre.style.whiteSpace='pre-wrap';
  pre.style.fontFamily='inherit';
  pre.style.fontSize='14px';
  pre.style.lineHeight='1.45';
  pre.style.padding='12px';
  pre.style.border='1px solid rgba(255,255,255,0.08)';
  pre.style.borderRadius='14px';
  pre.textContent = r.cuerpo || '(Sin cuerpo detectado)';
  wrap.appendChild(pre);

  return wrap;
}

function renderKV(obj){
  const wrap=document.createElement('div');
  for(const [k,v] of Object.entries(obj)){
    const row=document.createElement('div');
    row.className='kv';
    row.innerHTML=`<div class="k">${escapeHtml(k)}</div><div class="v">${escapeHtml(v??'')}</div>`;
    wrap.appendChild(row);
  }
  return wrap;
}
function openModal(title, sub, node){
  $('#modalTitle').textContent=title;
  $('#modalSub').textContent=sub||'';
  const body=$('#modalBody'); body.innerHTML=''; body.appendChild(node);
  $('#modal').classList.remove('hidden');
}
function closeModal(){ $('#modal').classList.add('hidden'); }

function topNCount(arr, keyFn, n=5){
  const map=new Map();
  for(const x of arr){ const k=norm(keyFn(x)||'N/D')||'N/D'; map.set(k,(map.get(k)||0)+1); }
  return Array.from(map.entries()).sort((a,b)=>b[1]-a[1]).slice(0,n);
}
function topNSum(arr, keyFn, sumFn, n=5){
  const map=new Map();
  for(const x of arr){ const k=norm(keyFn(x)||'N/D')||'N/D'; map.set(k,(map.get(k)||0)+(sumFn(x)||0)); }
  return Array.from(map.entries()).sort((a,b)=>b[1]-a[1]).slice(0,n);
}

function renderSparks(root, arr, kind){
  const byEstado=topNCount(arr, r=>r.estado, 4);
  const bySerie=topNCount(arr, r=> kind==='rfq' ? (r.tipo||'rfq') : r.serie, 4);
  const byDay=topNCount(arr, r=>parseDateToISO(r.fecha)||'N/D', 4);

  const box=(title, rows)=>{
    const max = rows[0]?.[1]||1;
    return `<div class="spark"><div class="sparkTitle">${escapeHtml(title)}</div>
      ${rows.map(([k,v])=>`
        <div class="sparkRow">
          <span>${escapeHtml(short(k,18))}</span>
          <span style="display:flex;align-items:center;gap:10px">
            <span>${escapeHtml(String(v))}</span>
            <span class="bar"><i style="width:${Math.min(100,(v/max)*100)}%"></i></span>
          </span>
        </div>`).join('')}
    </div>`;
  };
  root.innerHTML =
    box(kind==='rfq'?'RFQs por estado':(kind==='oferta'?'Ofertas por estado':'Pedidos por estado'), byEstado) +
    box(kind==='rfq'?'Emails por tipo':(kind==='oferta'?'Ofertas por serie':'Pedidos por serie'), bySerie) +
    box(kind==='rfq'?'RFQs últimos días':(kind==='oferta'?'Ofertas por día':'Pedidos por día'), byDay);
}

function renderList(root, items){
  root.innerHTML='';
  for(const it of items){
    const el=document.createElement('div');
    el.className='item';
    el.innerHTML = `
      <div class="itemTop">
        <div>
          <div class="itemTitle">${escapeHtml(it.title)}</div>
          <div class="itemMeta">${escapeHtml(it.meta)}</div>
        </div>
        <div class="badge ${it.badge.kind||''}">${escapeHtml(it.badge.text||'')}</div>
      </div>
      <div class="itemBottom">
        ${it.tags.map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}
        <span class="tag">Ver detalle</span>
      </div>
    `;
    el.addEventListener('click', it.onOpen);
    root.appendChild(el);
  }
}

function filterRows(rows, kind){
  const {serie, comercial, estadoOfertas, visado, estadoPedidos, desde, hasta, q} = state.filters;
  const ql = norm(q).toLowerCase();
  return rows.filter(r=>{
    if(serie && norm(r.serie)!==serie) return false;
    if(comercial && norm(r.comercial)!==comercial) return false;

    // filtros B (globales): se aplican según dataset
    if(kind==='ofertas'){
      if(estadoOfertas && norm(r.estado)!==estadoOfertas) return false;
      if(visado && norm(r.visado)!==visado) return false;
    }
    if(kind==='pedidos'){
      if(estadoPedidos && norm(r.estado)!==estadoPedidos) return false;
    }

    const iso=parseDateToISO(r.fecha);
    if(desde && iso && iso<desde) return false;
    if(hasta && iso && iso>hasta) return false;

    if(ql){
      const hay=[r.cliente,r.razon,r.numOferta,r.numPedido,r.idPedido,r.estado,r.obs,r.desc,r.comercial]
        .map(x=>norm(x).toLowerCase()).join(' | ');
      if(!hay.includes(ql)) return false;
    }
    return true;
  });
}

function filterRFQs(rows){
  const { desde, hasta, q } = state.filters;
  const ql = norm(q).toLowerCase();
  return rows.filter(r=>{
    const iso = parseDateToISO(r.fecha);
    if(desde && iso && iso<desde) return false;
    if(hasta && iso && iso>hasta) return false;

    // Ocultamos SPAM/Newsletter por defecto (se puede ver en RFQs detalle con filtro 'Todos')
    if(state.emailView !== 'todos' && norm(r.tipo).toLowerCase()==='spam') return false;

    // Filtro por tipo
    if(state.emailView && state.emailView!=='todos'){
      if(norm(r.tipo).toLowerCase() != state.emailView) return false;
    }

    if(ql){
      const hay=[r.empresa,r.id,r.asunto,r.cuerpo,r.email,r.estado]
        .map(x=>norm(x).toLowerCase()).join(' | ');
      if(!hay.includes(ql)) return false;
    }
    return true;
  });
}

function rebuildFilterOptions(){
  const series=new Set(), coms=new Set();
  const estOf=new Set(), estPe=new Set(), vis=new Set();
  for(const r of state.ofertasRaw){ if(r.serie) series.add(r.serie); if(r.comercial) coms.add(r.comercial); }
  for(const r of state.pedidosRaw){ if(r.serie) series.add(r.serie); if(r.comercial) coms.add(r.comercial); }

  for(const r of state.ofertasRaw){ if(r.estado) estOf.add(r.estado); if(r.visado) vis.add(r.visado); }
  for(const r of state.pedidosRaw){ if(r.estado) estPe.add(r.estado); }

  const serieSel=$('#filterSerie'), comSel=$('#filterComercial');
  const estOfSel=$('#filterEstadoOfertas'), visSel=$('#filterVisado'), estPeSel=$('#filterEstadoPedidos');

  const curS=serieSel.value, curC=comSel.value;
  const curEO=estOfSel?.value||'';
  const curV=visSel?.value||'';
  const curEP=estPeSel?.value||'';

  serieSel.innerHTML = '<option value="">Todas</option>' + Array.from(series).sort().map(s=>`<option>${escapeHtml(s)}</option>`).join('');
  comSel.innerHTML  = '<option value="">Todos</option>' + Array.from(coms).sort().map(s=>`<option>${escapeHtml(s)}</option>`).join('');

  if(estOfSel) estOfSel.innerHTML = '<option value="">Todos</option>' + Array.from(estOf).sort().map(s=>`<option>${escapeHtml(s)}</option>`).join('');
  if(visSel)   visSel.innerHTML   = '<option value="">Todos</option>' + Array.from(vis).sort().map(s=>`<option>${escapeHtml(s)}</option>`).join('');
  if(estPeSel) estPeSel.innerHTML = '<option value="">Todos</option>' + Array.from(estPe).sort().map(s=>`<option>${escapeHtml(s)}</option>`).join('');

  serieSel.value=curS||''; comSel.value=curC||'';
  if(estOfSel) estOfSel.value=curEO;
  if(visSel) visSel.value=curV;
  if(estPeSel) estPeSel.value=curEP;
}

function renderTables(ofertas, pedidos){
  const tbOf=$('#tblOfertas tbody'); tbOf.innerHTML='';
  for(const r of ofertas.slice(0, 800)){
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td>${escapeHtml(r.serie||'')}</td>
      <td>${escapeHtml(r.numOferta||'')}</td>
      <td>${escapeHtml(fmtDate(r.fecha)||'')}</td>
      <td>${escapeHtml(r.cliente||'')}</td>
      <td>${escapeHtml(r.razon||'')}</td>
      <td>${escapeHtml(r.comercial||'')}</td>
      <td>${escapeHtml(r.estado||'')}</td>
      <td>${escapeHtml(r.visado||'')}</td>
      <td class="right">${escapeHtml(fmtEUR(r.totalIva))}</td>
      <td class="obsCell">${escapeHtml(r.obs||'')}</td>
      <td class="right">${escapeHtml(r.idOferta||'')}</td>
    `;
    tr.addEventListener('click', ()=>openModal('Oferta', `${r.serie||''} · ${r.numOferta||''}`, renderKV({
      'Serie':r.serie,'Nº Oferta':r.numOferta,'Fecha':fmtDate(r.fecha),'Cliente':r.cliente,'Razón social':r.razon,
      'Comercial':r.comercial,'Estado':r.estado,'Visado':r.visado,'Total IVA':fmtEUR(r.totalIva),'Id Oferta':r.idOferta,'Observaciones':r.obs
    })));
    tbOf.appendChild(tr);
  }

  const tbPe=$('#tblPedidos tbody'); tbPe.innerHTML='';
  for(const r of pedidos.slice(0, 800)){
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td class="right">${escapeHtml(r.idPedido||'')}</td>
      <td>${escapeHtml(r.serie||'')}</td>
      <td>${escapeHtml(r.numPedido||'')}</td>
      <td>${escapeHtml(fmtDate(r.fecha)||'')}</td>
      <td>${escapeHtml(r.cliente||'')}</td>
      <td>${escapeHtml(r.razon||'')}</td>
      <td class="descCell">${escapeHtml(r.desc||'')}</td>
      <td>${escapeHtml(r.estado||'')}</td>
      <td class="right">${escapeHtml(fmtEUR(r.totalIva))}</td>
      <td class="obsCell">${escapeHtml(r.obs||'')}</td>
    `;
    tr.addEventListener('click', ()=>openModal('Pedido', `${r.serie||''} · ${r.numPedido||''}`, renderKV({
      'Id Pedido':r.idPedido,'Serie':r.serie,'Nº Pedido':r.numPedido,'Fecha':fmtDate(r.fecha),'Cliente':r.cliente,'Id Cliente':r.idCliente,
      'Razón social':r.razon,'Descripción':r.desc,'Estado':r.estado,'Total IVA':fmtEUR(r.totalIva),'Observaciones':r.obs
    })));
    tbPe.appendChild(tr);
  }
}

function renderRFQs(rfqs){
  const por=countWhere(rfqs, r=>/por contestar/i.test(r.estado||''));
  const cont=countWhere(rfqs, r=>/contestad/i.test(r.estado||''));
  const prop=countWhere(rfqs, r=>/propuesta/i.test(r.estado||''));
  $('#rfqK1').textContent=por; $('#rfqK2').textContent=cont; $('#rfqK3').textContent=prop; $('#rfqK4').textContent=rfqs.length;

  renderList($('#rfqList'), rfqs.slice(0,8).map(r=>({
    title:`${r.empresa} · ${r.id}`,
    meta:`${fmtDate(r.fecha)} · ${r.email}`,
    badge: badgeFromEstado(r.estado),
    tags:[`Tipo: ${(r.tipo||'rfq').toUpperCase()}`, `Estado: ${r.estado}`, r.tel?`Tel: ${r.tel}`:'Tel: —', `Asunto: ${short(r.asunto,34)}`],
    onOpen: ()=>openModal('Email', `${r.empresa} · ${r.id}`, renderRFQModal(r))
  })));

  const panel=$('#rfqPanelList');
  if(panel){
    panel.innerHTML='';
    for(const r of rfqs){
      const el=document.createElement('div');
      el.className='item';
      el.innerHTML=`
        <div class="itemTop">
          <div>
            <div class="itemTitle">${escapeHtml(r.empresa)} · ${escapeHtml(r.id)}</div>
            <div class="itemMeta">${escapeHtml(fmtDate(r.fecha)||'')} · ${escapeHtml(r.email||'')}</div>
          </div>
          <div class="badge ${badgeFromEstado(r.estado).kind}">${escapeHtml((r.tipo||'rfq').toUpperCase())}</div>
        </div>
        <div class="itemBottom">
          <span class="tag">Estado: ${escapeHtml(r.estado||'')}</span>
          <span class="tag">Asunto: ${escapeHtml(short(r.asunto,58))}</span>
          <span class="tag">Ver email</span>
        </div>
      `;
      el.addEventListener('click', ()=>openModal('Email', `${r.empresa} · ${r.id}`, renderRFQModal(r)));
      panel.appendChild(el);
    }
  }
}

function renderAll(){
  // v45.4: SIEMPRE orden por fecha (toggle ▼/▲)
  const ofertas = sortByFecha(filterRows(state.ofertasRaw,'ofertas'), state.sort.ofertas);
  const pedidos = sortByFecha(filterRows(state.pedidosRaw,'pedidos'), state.sort.pedidos);
  const rfqs    = sortByFecha(filterRFQs(state.rfqs), state.sort.rfqs);

  $('#kpiOfertas').textContent = ofertas.length.toLocaleString('es-ES');
  $('#kpiPedidos').textContent = pedidos.length.toLocaleString('es-ES');
  $('#kpiImporteOfertado').textContent = fmtEUR(sum(ofertas, r=>r.totalIva));
  $('#kpiImportePedido').textContent = fmtEUR(sum(pedidos, r=>r.totalIva));


  renderList($('#ofertasList'), ofertas.slice(0,10).map(r=>({
    title:`${r.cliente||'Sin cliente'} · Oferta ${r.numOferta||'—'}`,
    meta:`${r.serie||'—'} · ${fmtDate(r.fecha)} · ${r.comercial||'—'}`,
    badge: badgeFromEstado(r.estado),
    tags:[`Estado: ${r.estado||'—'}`, `Importe: ${fmtEUR(r.totalIva)}`, `Visado: ${r.visado||'—'}`],
    onOpen: ()=>openModal('Oferta', `${r.serie||''} · ${r.numOferta||''}`, renderKV({
      'Serie':r.serie,'Nº Oferta':r.numOferta,'Fecha':fmtDate(r.fecha),'Cliente':r.cliente,'Razón social':r.razon,
      'Comercial':r.comercial,'Estado':r.estado,'Visado':r.visado,'Total IVA':fmtEUR(r.totalIva),'Id Oferta':r.idOferta,'Observaciones':r.obs
    }))
  })));

  renderList($('#pedidosList'), pedidos.slice(0,10).map(r=>({
    title:`${r.cliente||'Sin cliente'} · Pedido ${r.numPedido||'—'}`,
    meta:`ID ${r.idPedido||'—'} · ${r.serie||'—'} · ${fmtDate(r.fecha)}`,
    badge: badgeFromEstado(r.estado),
    tags:[`Estado: ${r.estado||'—'}`, `Importe: ${fmtEUR(r.totalIva)}`, r.razon?`Razón: ${short(r.razon,34)}`:'Razón: —'],
    onOpen: ()=>openModal('Pedido', `${r.serie||''} · ${r.numPedido||''}`, renderKV({
      'Id Pedido':r.idPedido,'Serie':r.serie,'Nº Pedido':r.numPedido,'Fecha':fmtDate(r.fecha),'Cliente':r.cliente,'Id Cliente':r.idCliente,
      'Razón social':r.razon,'Descripción':r.desc,'Estado':r.estado,'Total IVA':fmtEUR(r.totalIva),'Observaciones':r.obs
    }))
  })));

  const ofAcept=countWhere(ofertas, r=>/acept/i.test(r.estado||''));
  const ofRech=countWhere(ofertas, r=>/rech/i.test(r.estado||''));
  const ofEnv=countWhere(ofertas, r=>/envi/i.test(r.estado||''));
  $('#ofK1').textContent=ofEnv; $('#ofK2').textContent=ofAcept; $('#ofK3').textContent=ofRech; $('#ofK4').textContent=fmtEUR(sum(ofertas,r=>r.totalIva));

  const peEnCurso=countWhere(pedidos, r=>/curso|prepar|produ/i.test(r.estado||''));
  const pePend=countWhere(pedidos, r=>/pend/i.test(r.estado||''));
  const peFin=countWhere(pedidos, r=>/final|complet/i.test(r.estado||''));
  $('#peK1').textContent=peEnCurso; $('#peK2').textContent=pePend; $('#peK3').textContent=peFin; $('#peK4').textContent=fmtEUR(sum(pedidos,r=>r.totalIva));

  renderSparks($('#ofertasSparks'), ofertas, 'oferta');
  renderSparks($('#pedidosSparks'), pedidos, 'pedido');
  renderSparks($('#rfqSparks'), rfqs, 'rfq');

  renderTables(ofertas, pedidos);
  renderRFQs(rfqs);
}

function setView(name){
  $$('.pill').forEach(p=>p.classList.toggle('active', p.dataset.view===name));
  $('#view-home').classList.toggle('hidden', name!=='home');
  $('#view-ofertas').classList.toggle('hidden', name!=='ofertas');
  $('#view-pedidos').classList.toggle('hidden', name!=='pedidos');
  $('#view-rfqs').classList.toggle('hidden', name!=='rfqs');
}

function exportCSV(rows, fileName){
  if(!rows.length){ alert('No hay datos para exportar'); return; }
  const cols=Object.keys(rows[0]);
  const lines=[cols.join(';')].concat(rows.map(r=>cols.map(c=>{
    const v=r[c]??''; const s=String(v).replace(/\r?\n/g,' ').trim();
    return s.includes(';')||s.includes('"') ? '"'+s.replace(/"/g,'""')+'"' : s;
  }).join(';')));
  const blob=new Blob([lines.join('\n')], {type:'text/csv;charset=utf-8'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=fileName; a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href), 1000);
}

function loadOfertasFromCSV(text){
  const {cols,rows}=parseCSV(text);
  const idx=pickCol(mapOfertas, cols);
  state.ofertasRaw=rows.map(r=>({
    // mapeo requerido v45.3
    'Serie': r[idx.serie]??'',
    'NumOferta': r[idx.numOferta]??'',
    'EstadoDescrip': r[idx.estado]??'',
    'Visado': r[idx.visado]??'',
    'TotalIVA': toNumber(r[idx.totalIva]),

    // campos operativos/UI
    serie:r[idx.serie]??'',
    numOferta:r[idx.numOferta]??'',
    fecha:r[idx.fecha]??'',
    idCliente:r[idx.idCliente]??'',
    cliente:r[idx.cliente]??'',
    razon:r[idx.razon]??'',
    comercial:r[idx.comercial]??'',
    estado:r[idx.estado]??'',
    visado:r[idx.visado]??'',
    obs:r[idx.obs]??'',
    totalIva:toNumber(r[idx.totalIva]),
    idOferta:r[idx.idOferta]??''
  }));
  rebuildFilterOptions();
  renderAll();
}
function loadPedidosFromCSV(text){
  const {cols,rows}=parseCSV(text);
  const idx=pickCol(mapPedidos, cols);
  state.pedidosRaw=rows.map(r=>({
    // mapeo requerido v45.3
    'Pedido (ID)': r[idx.idPedido]??'',
    'Serie': r[idx.serie]??'',
    'NúmeroPedido': r[idx.numPedido]??'',
    'Estado': r[idx.estado]??'',
    'TotalIVA': toNumber(r[idx.totalIva]),

    // campos operativos/UI
    idPedido:r[idx.idPedido]??'',
    serie:r[idx.serie]??'',
    numPedido:r[idx.numPedido]??'',
    fecha:r[idx.fecha]??'',
    cliente:r[idx.cliente]??'',
    idCliente:r[idx.idCliente]??'',
    razon:r[idx.razon]??'',
    desc:r[idx.desc]??'',
    estado:r[idx.estado]??'',
    totalIva:toNumber(r[idx.totalIva]),
    obs:r[idx.obs]??'',
    comercial:''
  }));
  rebuildFilterOptions();
  renderAll();
}

function sampleOfertasCSV(){
  return `Serie;NumOferta;Fecha;Id Cliente;Cliente;Razón Social;Comercial;EstadoDescrp;Visado;Observaciones;TotalIVA;Id Oferta
FV;250009;10/09/2025 13:33;430005993;CARAMELOS Y CHOCOLATES;MAS QUE UN CARAMELO C&CH, S.L.;JUAN MANUEL RIEGO;Aceptada;VERDADERO;"170 LATAS ...";0;57336
FN;250530;10/09/2025 15:15;430033653;SUPERMERCADOS LLOBET SA;SUPERMERCADOS LLOBET SA;Supervisor InnProRes;Generada;FALSO;"100 UNIDADES ...";4664,55;57338
FN;250533;11/09/2025 0:00;430003233;REPSOL S.A;REPSOL S.A.;JUANA ROMERO;Aceptada;FALSO;"307.200 UDS ...";20342,78;57341
`;
}
function samplePedidosCSV(){
  return `Id Pedido;Serie;NúmeroPedido;Observaciones;Descripción Pedido;Estado;Fecha;Cliente;Id Cliente;Razón Social;TotalIVA
71603;FH;250627;"ENTREGA ...";CAJITAS CUBO HOTEL SANT FRANCESC;COMPLETADO;18/07/2025 0:00;HOTEL SANT FRANCESC;430009164;SANT FRANCESC HOTEL SINGULAR;1633,5
71604;FH;250628;"PLAZO ...";NAPOLITANAS SABORES PREMIUM SANT FRANCESC.;COMPLETADO;18/07/2025 0:00;HOTEL SANT FRANCESC;430009164;SANT FRANCESC HOTEL SINGULAR;1585,1
71610;FN;250476;"DIRECCIÓN POR CONFIRMAR";SACHET CON BOLSITA DE TÉ (RELAX);COMPLETADO;21/07/2025 0:00;Monterreina Comunicación s.l.u;430033216;Monterreina Comunicación s.l.u;296,45
`;
}


async function loadEmailsInboxJSON(){
  try{
    const res = await fetch(`./emails_inbox.json?ts=${Date.now()}`, { cache: 'no-store' });
    if(!res.ok) throw new Error('No emails_inbox.json');
    const data = await res.json();
    if(!Array.isArray(data)) throw new Error('emails_inbox.json no es array');

    state.rfqs = data.map((raw, i)=>{
      const from = raw.fromEmail || raw.email || raw.from || raw.senderEmail || raw.sender || '';
      const fromName = raw.fromName || raw.name || '';
      const subj = raw.subject || raw.asunto || '(sin asunto)';
      const cuerpo = getEmailBody(raw);
      const tipo = raw.tipo || classifyEmail(raw);
      const fechaRaw = raw.dateISO || raw.fechaISO || raw.date || raw.fecha || raw.sentAt || raw.receivedAt || raw.internalDate || '';
      const fecha = String(fechaRaw||'').slice(0,10);

      return {
        id: String(raw.uid || raw.id || raw.messageId || (i+1)),
        empresa: norm(fromName || (String(from).split('@')[0]||'Email')),
        email: norm(from),
        tel: raw.tel || raw.telefono || '',
        estado: raw.estado || 'Por contestar',
        fecha: fecha || 'N/D',
        asunto: subj,
        cuerpo: cuerpo,
        tipo: tipo,
        raw
      };
    });

  }catch(err){
    seedRFQs();
  }
}


function seedRFQs(){
  state.rfqs=[
    {id:'RFQ-1',empresa:'Alfa Retail',email:'compras@alfa.com',tel:'+34 600 111 222',estado:'Por contestar',fecha:'2025-10-02',asunto:'Bolsas 10.000 uds',cuerpo:'Necesito oferta para bolsas personalizadas.'},
    {id:'RFQ-2',empresa:'Bravo Foods',email:'compras@bravo.com',tel:'+34 600 222 333',estado:'Propuesta en curso',fecha:'2025-10-05',asunto:'Cajas microcanal 5.000 uds',cuerpo:'Envío a Valencia. ¿Incluye troquel?'},
    {id:'RFQ-3',empresa:'Hotel Mar Azul',email:'compras@marazul.com',tel:'',estado:'Contestada',fecha:'2025-10-06',asunto:'Amenities · packaging',cuerpo:'Estamos valorando amenities para temporada alta.'}
  ];
}

function bindEvents(){
  $$('.pill[data-view]').forEach(p=>p.addEventListener('click',()=>setView(p.dataset.view)));
  $$('[data-open-panel]').forEach(b=>b.addEventListener('click',(e)=>{e.preventDefault(); setView(b.dataset.openPanel); window.scrollTo({top:0,behavior:'smooth'});}));

  $('#modal').addEventListener('click',(e)=>{ if(e.target?.dataset?.close) closeModal(); });
  document.addEventListener('keydown',(e)=>{ if(e.key==='Escape') closeModal(); });

  $('#filterSerie').addEventListener('change',e=>{state.filters.serie=e.target.value; renderAll();});
  $('#filterComercial').addEventListener('change',e=>{state.filters.comercial=e.target.value; renderAll();});
  $('#filterEstadoOfertas').addEventListener('change',e=>{state.filters.estadoOfertas=e.target.value; renderAll();});
  $('#filterVisado').addEventListener('change',e=>{state.filters.visado=e.target.value; renderAll();});
  $('#filterEstadoPedidos').addEventListener('change',e=>{state.filters.estadoPedidos=e.target.value; renderAll();});
  $('#filterDesde').addEventListener('change',e=>{state.filters.desde=e.target.value; renderAll();});
  $('#filterHasta').addEventListener('change',e=>{state.filters.hasta=e.target.value; renderAll();});
  $('#filterQuery').addEventListener('input',e=>{state.filters.q=e.target.value; renderAll();});

  const emailViewSel = $('#filterEmailView');
  if(emailViewSel){
    emailViewSel.addEventListener('change', e=>{ state.emailView = e.target.value; renderAll(); });
  }

  // v45.4: toggles de orden por fecha (▼/▲) por bloque
  const sortBtns = [
    ['#btnSortRFQs','rfqs'], ['#btnSortRFQs2','rfqs'],
    ['#btnSortOfertas','ofertas'], ['#btnSortOfertas2','ofertas'],
    ['#btnSortPedidos','pedidos'], ['#btnSortPedidos2','pedidos'],
  ];
  for(const [sel, kind] of sortBtns){
    const el = $(sel);
    if(el) el.addEventListener('click', (e)=>{ e.preventDefault(); e.stopPropagation(); toggleSort(kind); });
  }

  $('#btnReset').addEventListener('click',()=>{
    state.filters={serie:'',comercial:'',estadoOfertas:'',visado:'',estadoPedidos:'',desde:'',hasta:'',q:''};
    $('#filterSerie').value='';
    $('#filterComercial').value='';
    $('#filterEstadoOfertas').value='';
    $('#filterVisado').value='';
    $('#filterEstadoPedidos').value='';
    $('#filterDesde').value='';
    $('#filterHasta').value='';
    $('#filterQuery').value='';
    renderAll();
  });

  $('#fileOfertas').addEventListener('change', async (e)=>{ const f=e.target.files?.[0]; if(!f) return; loadOfertasFromCSV(await f.text()); });
  $('#filePedidos').addEventListener('change', async (e)=>{ const f=e.target.files?.[0]; if(!f) return; loadPedidosFromCSV(await f.text()); });

  $('#btnSampleOfertas').addEventListener('click',()=>loadOfertasFromCSV(sampleOfertasCSV()));
  $('#btnSamplePedidos').addEventListener('click',()=>loadPedidosFromCSV(samplePedidosCSV()));

  $('#btnExportOfertas').addEventListener('click',()=>exportCSV(sortByFecha(filterRows(state.ofertasRaw,'ofertas'), state.sort.ofertas),'ofertas_filtradas.csv'));
  $('#btnExportPedidos').addEventListener('click',()=>exportCSV(sortByFecha(filterRows(state.pedidosRaw,'pedidos'), state.sort.pedidos),'pedidos_filtrados.csv'));
  $('#btnExportOfertas2').addEventListener('click',()=>exportCSV(sortByFecha(filterRows(state.ofertasRaw,'ofertas'), state.sort.ofertas),'ofertas_filtradas.csv'));
  $('#btnExportPedidos2').addEventListener('click',()=>exportCSV(sortByFecha(filterRows(state.pedidosRaw,'pedidos'), state.sort.pedidos),'pedidos_filtrados.csv'));

  $('#btnAyuda').addEventListener('click',()=>openModal('Ayuda CSV','Columnas esperadas (mapeo tolerante)',renderKV({
    'Ofertas':'Serie, NumOferta, Fecha, Id Cliente, Cliente, Razón Social, Comercial, EstadoDescrp, Visado, Observaciones, TotalIVA, Id Oferta',
    'Pedidos':'Id Pedido, Serie, NúmeroPedido, Fecha, Cliente, Id Cliente, Razón Social, Descripción Pedido, Estado, TotalIVA, Observaciones'
  })));

  $('#btnAddFakeRFQ').addEventListener('click',()=>{
    const n=state.rfqs.length+1;
    state.rfqs.unshift({id:`RFQ-${n}`,empresa:`Empresa Demo ${n}`,email:`demo${n}@empresa.com`,tel:'',estado:['Por contestar','Propuesta en curso','Contestada'][n%3],fecha:new Date().toISOString().slice(0,10),asunto:`RFQ demo ${n}`,cuerpo:'Texto demo.'});
    renderAll();
  });

  $('#btnTestRFQ').addEventListener('click',()=>{
    openModal('Test RFQ','Simulación rápida',renderKV({'Acción':'Abre RFQs y valida lectura tipo email','Siguiente':'Tras validar v45, conectamos IMAP real.'}));
    setTimeout(()=>setView('rfqs'),150);
  });
}

async function init(){
  await loadEmailsInboxJSON();
  bindEvents();
  setSortIcon('rfqs');
  setSortIcon('ofertas');
  setSortIcon('pedidos');
  renderAll();
  setView('home');
}
init();
