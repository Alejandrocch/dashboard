let STATE = {
  rfqs: [], offers: [], orders: [], billing: [],
  objectives: { nac:0, exp:0, hot:0, car:0, breakdown:{} },
  analytics: { ordersByYear: {}, offersByYear: {}, mode: 'orders' }
};
let charts = {};

// --- Acceso / Roles (local) ---
let CURRENT_VIEW = 'dashboard';
const USERS = [
  { id: 'alejandro', name: 'Alejandro', role: 'admin', label: 'Administrador general (todo)' },
  { id: 'david', name: 'David', role: 'produccion', label: 'Producción (solo Producción)' },
  { id: 'rafa', name: 'Rafa', role: 'produccion', label: 'Producción (solo Producción)' },
  { id: 'isabel', name: 'Isabel', role: 'facturacion', label: 'Facturación (solo Facturación)' },
  { id: 'diego', name: 'Diego', role: 'facturacion', label: 'Facturación (solo Facturación)' },
];

const ROLE_VIEWS = {
  admin: ['dashboard','analytics','objetivos','facturacion','produccion','informes','rfqs','offers','orders','panel-diario'],
  produccion: ['dashboard','produccion','informes','panel-diario'],
  facturacion: ['dashboard','facturacion','informes','panel-diario'],
};

function getCurrentUser(){
  const id = localStorage.getItem('pg_user') || 'alejandro';
  return USERS.find(u=>u.id===id) || USERS[0];
}
function setCurrentUser(id){
  localStorage.setItem('pg_user', id);
}
function applyRoleVisibility(){
  const user = getCurrentUser();
  const allowed = new Set(ROLE_VIEWS[user.role] || ROLE_VIEWS.admin);
  document.querySelectorAll('.nav-btn').forEach(btn=>{
    const view = (btn.getAttribute('data-view') || '').toLowerCase();
    const ok = allowed.has(view);
    btn.style.display = ok ? '' : 'none';
  });
  if (!allowed.has(CURRENT_VIEW)) {
    CURRENT_VIEW = 'dashboard';
  }
}


// Fallback: si Chart.js no está disponible (sin internet / CSP), evitamos que la app se rompa.
function safeChart(ctx, cfg){
  if(typeof Chart === 'undefined'){
    console.warn('Chart.js no disponible: se omiten gráficos');
    return null;
  }
  try{
    return new Chart(ctx, cfg);
  }catch(err){
    console.warn('Error creando gráfico (Chart.js):', err);
    return null;
  }
}

// Storage
const LS_KEY = 'cch_v55_db';
// localStorage tiene un límite (normalmente ~5MB). Los pedidos (filas) pueden excederlo.
// Guardamos las filas completas de pedidos en IndexedDB y en localStorage solo dejamos resúmenes.
const IDB_NAME = 'cch_panelgeneral_db';
const IDB_VERSION = 1;
const IDB_STORE_ORDERS = 'orders_raw_by_year';

// Cache en memoria (no se persiste en localStorage)
const ORDERS_ROWS_CACHE = Object.create(null);

function idbOpen(){
  return new Promise((resolve, reject) => {
    try{
      const req = indexedDB.open(IDB_NAME, IDB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if(!db.objectStoreNames.contains(IDB_STORE_ORDERS)){
          db.createObjectStore(IDB_STORE_ORDERS, { keyPath: 'year' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }catch(err){ reject(err); }
  });
}

async function idbSetYearRows(year, rows){
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE_ORDERS, 'readwrite');
    tx.objectStore(IDB_STORE_ORDERS).put({ year, rows });
    tx.oncomplete = () => { db.close(); resolve(true); };
    tx.onerror = () => { const e = tx.error || new Error('IndexedDB error'); db.close(); reject(e); };
  });
}

async function idbGetYearRows(year){
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE_ORDERS, 'readonly');
    const req = tx.objectStore(IDB_STORE_ORDERS).get(year);
    req.onsuccess = () => { const v = req.result ? req.result.rows : null; db.close(); resolve(v); };
    req.onerror = () => { const e = req.error || new Error('IndexedDB error'); db.close(); reject(e); };
  });
}

async function idbDeleteYearRows(year){
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE_ORDERS, 'readwrite');
    tx.objectStore(IDB_STORE_ORDERS).delete(year);
    tx.oncomplete = () => { db.close(); resolve(true); };
    tx.onerror = () => { const e = tx.error || new Error('IndexedDB error'); db.close(); reject(e); };
  });
}

async function idbClearAll(){
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE_ORDERS, 'readwrite');
    tx.objectStore(IDB_STORE_ORDERS).clear();
    tx.oncomplete = () => { db.close(); resolve(true); };
    tx.onerror = () => { const e = tx.error || new Error('IndexedDB error'); db.close(); reject(e); };
  });
}

window.nav = function(view) {
    try {
        CURRENT_VIEW = (view || 'dashboard').toLowerCase();
        applyRoleVisibility();
        // Si por rol no está permitido, forzamos dashboard
        const user = getCurrentUser();
        const allowed = new Set(ROLE_VIEWS[user.role] || ROLE_VIEWS.admin);
        if (!allowed.has(CURRENT_VIEW)) {
            CURRENT_VIEW = 'dashboard';
        }

        document.querySelectorAll('.view-section').forEach(e => e.classList.add('hidden'));
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    
        const isTable = ['rfqs','offers','orders'].includes(CURRENT_VIEW);
        if (isTable) {
            const vt = document.getElementById('view-table');
            if (vt) vt.classList.remove('hidden');
            renderTable(CURRENT_VIEW);
        } else {
            const target = document.getElementById(`view-${CURRENT_VIEW}`);
            if (target) {
                target.classList.remove('hidden');
            } else {
                // Fallback: nunca dejar la app en blanco
                const vd = document.getElementById('view-dashboard');
                if (vd) vd.classList.remove('hidden');
                CURRENT_VIEW = 'dashboard';
            }
        }

        const btn = Array.from(document.querySelectorAll('.nav-btn')).find(b => (b.dataset.view || '').toLowerCase() === CURRENT_VIEW);
        if (btn) btn.classList.add('active');

        if(CURRENT_VIEW === 'analytics') renderAnalytics();
        if(CURRENT_VIEW === 'produccion') renderGantt();
        if(CURRENT_VIEW === 'objetivos') { renderMiniCharts(); renderObjectiveCharts(); }
        if(CURRENT_VIEW === 'facturacion') {
            try { initBillingUI(); renderBilling(); } catch(e){ console.error('Billing error', e); }
        }
    } catch (err) {
        console.error('NAV ERROR', err);
        // Fallback absoluto
        const vd = document.getElementById('view-dashboard');
        if (vd) vd.classList.remove('hidden');
    }
};

document.addEventListener('DOMContentLoaded', () => {
    restoreState();
    // Mostrar estado de autoguardado al arrancar
    updateAutosaveStatus();
    initMocks();
    initHandlers();
    initNavBindings();
    applyRoleVisibility();
    updateUI();
    nav('dashboard');
});

// Navegación robusta: sin onclick inline (CSP/Hostinger)
function initNavBindings(){
    document.querySelectorAll('.nav-btn[data-view]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const v = btn.dataset.view;
            if (v) window.nav(v);
        });
    });
}

function openUserModal(){
    const backdrop = document.getElementById('user-modal');
    const grid = document.getElementById('user-grid');
    if (!backdrop || !grid) return;
    const current = getCurrentUser();
    grid.innerHTML = '';
    USERS.forEach(u=>{
        const el = document.createElement('div');
        el.className = 'user-card';
        el.innerHTML = `<div class="name">${u.name}${u.id===current.id ? ' ✅' : ''}</div><div class="role">${u.label}</div>`;
        el.onclick = ()=>{
            setCurrentUser(u.id);
            applyRoleVisibility();
            nav(CURRENT_VIEW);
            closeUserModal();
        };
        grid.appendChild(el);
    });
    backdrop.style.display = 'flex';
}
function closeUserModal(){
    const backdrop = document.getElementById('user-modal');
    if (backdrop) backdrop.style.display = 'none';
}
window.__closeUserModal = closeUserModal;

function initHandlers() {
    document.getElementById('btn-layout').onclick = () => document.getElementById('app-container').classList.toggle('layout-side-nav');
    // Tema Día/Noche (con icono)
    const btnTheme = document.getElementById('btn-theme');
    const applyThemeIcon = () => {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        const i = btnTheme?.querySelector('i');
        if (i) i.className = isDark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
    };
    // Restaurar tema
    const savedTheme = localStorage.getItem('pg_theme');
    if (savedTheme === 'dark' || savedTheme === 'light') {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }
    applyThemeIcon();
    btnTheme.onclick = () => {
        const d = document.documentElement;
        const next = d.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        d.setAttribute('data-theme', next);
        localStorage.setItem('pg_theme', next);
        applyThemeIcon();
    };

    // Ajustes (dropdown)
    const btnSettings = document.getElementById('btn-settings');
    const menu = document.getElementById('settings-menu');
    const toggleMenu = (force) => {
        if (!menu) return;
        const show = typeof force === 'boolean' ? force : (menu.style.display === 'none');
        menu.style.display = show ? 'block' : 'none';
    };
    if (btnSettings && menu) {
        btnSettings.onclick = (e) => { e.stopPropagation(); toggleMenu(); };
        document.addEventListener('click', () => toggleMenu(false));
        menu.addEventListener('click', (e)=> e.stopPropagation());
    }

    // Backup/Restore local (panelgeneral.json) -> dentro de Ajustes
    const btnBackup = document.getElementById('menu-backup');
    const btnRestore = document.getElementById('menu-restore');
    const inputRestore = document.getElementById('restore-file');

    if (btnBackup) btnBackup.onclick = () => {
        try {
            const payload = {
                exportedAt: new Date().toISOString(),
                state: STATE
            };
            const blob = new Blob([JSON.stringify(payload, null, 2)], {type: 'application/json'});
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'panelgeneral.json';
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(a.href), 5000);
        } catch(err) {
            console.error(err);
            alert('No he podido generar el backup JSON.');
        }
    };

    if (btnRestore && inputRestore) btnRestore.onclick = () => inputRestore.click();
    if (inputRestore) inputRestore.onchange = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        try {
            const txt = await file.text();
            const obj = JSON.parse(txt);
            if (obj?.state) STATE = obj.state;
            else if (obj) STATE = obj;
            saveState();
            updateUI();
            alert('Backup cargado.');
        } catch(err) {
            console.error(err);
            alert('El archivo no parece un panelgeneral.json válido.');
        } finally {
            inputRestore.value = '';
        }
    };

    // Usuarios / Roles
    const btnUser = document.getElementById('menu-user');
    if (btnUser) btnUser.onclick = () => { openUserModal(); };

    document.getElementById('file-offers').onchange = (e) => loadCSV(e, 'offers');
    document.getElementById('file-orders').onchange = (e) => loadCSV(e, 'orders');
    document.getElementById('file-bill').onchange = (e) => loadBillingFile(e);

    // Filtros del dashboard (Sección / Comercial)
    const fSerie = document.getElementById('f-serie');
    const fAgent = document.getElementById('f-agent');
    if(fSerie) fSerie.addEventListener('change', () => { window.__CCH_FILTER_SERIE = String(fSerie.value||'all'); updateUI(); });
    if(fAgent) fAgent.addEventListener('change', () => { window.__CCH_FILTER_AGENT = String(fAgent.value||'Todos'); updateUI(); });

    initGlobalSearchAndMic();
    initBillingUI();

    // Analítica (pedidos por año) – handlers seguros (existen aunque la vista esté oculta)
    initAnalyticsHandlers();
}

function restoreState() {
    const s = localStorage.getItem('cch_v55_db');
    if(s) STATE = JSON.parse(s);
    // backward compatible
    if(!STATE.analytics) STATE.analytics = { ordersByYear: {}, offersByYear: {}, mode: 'orders' };
    if(!STATE.analytics.ordersByYear) STATE.analytics.ordersByYear = {};
    if(!STATE.analytics.offersByYear) STATE.analytics.offersByYear = {};
    if(!STATE.analytics.mode) STATE.analytics.mode = 'orders';
}

function _fmtHHMM(d){
    const hh = String(d.getHours()).padStart(2,'0');
    const mm = String(d.getMinutes()).padStart(2,'0');
    return `${hh}:${mm}`;
}

function updateAutosaveStatus(ts=null){
    const el = document.getElementById('autosave-status');
    if(!el) return;
    let t = ts;
    if(!t) {
        const raw = localStorage.getItem('cch_panel_last_save');
        t = raw ? new Date(parseInt(raw,10)) : null;
    }
    el.textContent = t ? `Guardado OK (${_fmtHHMM(t)})` : '⟳ listo';
}

function saveState() {
    // localStorage tiene un límite; evitamos guardar datasets grandes.
    // Las filas completas de pedidos se almacenan en IndexedDB; aquí solo guardamos resúmenes.
    const safe = JSON.parse(JSON.stringify(STATE));
    if (safe && safe.analytics && safe.analytics.ordersByYear) {
        for (const y of Object.keys(safe.analytics.ordersByYear)) {
            if (safe.analytics.ordersByYear[y] && safe.analytics.ordersByYear[y].rows) {
                delete safe.analytics.ordersByYear[y].rows; // seguridad extra
            }
        }
    }

    try {
        localStorage.setItem('cch_v55_db', JSON.stringify(safe));
    } catch (e) {
        // Si aun así se excede la cuota, guardamos una versión mínima.
        console.warn('saveState quota exceeded; saving minimal state', e);
        const minimal = {
            objectives: safe.objectives,
            analytics: { ordersByYear: safe.analytics?.ordersByYear || {} },
        };
        try {
            localStorage.setItem('cch_v55_db', JSON.stringify(minimal));
        } catch (e2) {
            // Último recurso: no rompemos la UI.
            console.warn('Unable to save even minimal state', e2);
        }
    }
    const now = Date.now();
    localStorage.setItem('cch_panel_last_save', String(now));
    updateAutosaveStatus(new Date(now));
}

// --- PARSER OBJETIVOS BLINDADO v55 ---
window.triggerObjUpload = (key) => document.getElementById(`file-obj-${key}`).click();
window.loadObjectiveCSV = function(el, key, filterKeyword='') {
    const file = el.files[0];
    if(!file) return;

    if(file.name.toLowerCase().endsWith('.xlsx')) {
        alert("⚠️ ATENCIÓN: El navegador no puede leer .xlsx. Guarda como CSV en Excel.");
        return;
    }

    // keywords (fallback legacy)
    let kwList = Array.isArray(filterKeyword)
        ? filterKeyword.map(s => String(s || '').toLowerCase()).filter(Boolean)
        : [String(filterKeyword || '').toLowerCase()].filter(Boolean);

    // Regla especial legacy: NACIONAL = CARM = Promoción + Caramelos
    if(key === 'nac' && kwList.length === 1 && kwList[0] === 'promocion') {
        kwList = ['promocion','promoción','caramel','caramelo','caramelos','carm'];
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        try{
            const text = e.target.result || '';
            const lines = text.replace(/^\uFEFF/, '').split(/\r\n|\n/).filter(l => l !== undefined);

            const delim = (lines[0] && lines[0].includes(';')) ? ';' : ',';

            const parseNum = (valStr) => {
                if(valStr === undefined || valStr === null) return 0;
                let s = String(valStr).trim().replace(/"/g,'');
                if(!s) return 0;
                // Normalización ES/EN:
                //  - 334.000  -> 334000
                //  - 334.000,50 -> 334000.50
                //  - 334,50  -> 334.50
                if(s.includes('.') && s.includes(',')) {
                    // punto = miles, coma = decimales
                    s = s.replace(/\./g,'').replace(',','.');
                } else if(s.includes(',') && !s.includes('.')) {
                    // coma = decimales
                    s = s.replace(',','.');
                } else if(s.includes('.') && !s.includes(',')) {
                    // Si el patrón es miles (1.234 o 12.345.678), quitamos los puntos
                    if(/^\d{1,3}(\.\d{3})+$/.test(s)) {
                        s = s.replace(/\./g,'');
                    }
                }
                const n = parseFloat(s);
                return isNaN(n) ? 0 : n;
            };

            const monthMap = {ENERO:0,FEBRERO:1,MARZO:2,ABRIL:3,MAYO:4,JUNIO:5,JULIO:6,AGOSTO:7,SEPTIEMBRE:8,OCTUBRE:9,NOVIEMBRE:10,DICIEMBRE:11};

            // === PARSER NUEVO (CSV FINAL) PARA NACIONAL / EXPORT: Objetivo vs Real ===
            const hasObj = text.toLowerCase().includes('objetivo');
            if((key === 'nac' || key === 'exp' || key === 'hot' || key === 'car') && hasObj){
                const realMonthly = new Array(12).fill(0);
                const objMonthly  = new Array(12).fill(0);

                for(const raw of lines){
                    if(!raw) continue;
                    const cols = raw.split(delim);
                    const m = String(cols[0]||'').trim().toUpperCase();
                    if(monthMap[m] === undefined) continue;
                    const mi = monthMap[m];

                    if(key === 'nac'){
                        // Estructura (según DESGLOSE VENTAS NACIONAL 2025_FINAL.csv):
                        // MES; REAL_CARAM; OBJ_CARAM; ; REAL_PROMO; ; OBJ_PROMO; REAL_TOTAL; ; OBJ_TOTAL
                        const realTotal = parseNum(cols[7]);
                        const objTotal  = parseNum(cols[9]) || (parseNum(cols[2]) + parseNum(cols[6]));
                        realMonthly[mi] = realTotal;
                        objMonthly[mi]  = objTotal;
                    }else if(key === 'exp'){
                        // Estructura (según DESGLOSE VENTAS EXPORT 2025_FINAL.csv):
                        // MES; AGENCIAS; CLIENTES; ... ; TOTAL_REAL; OBJETIVO_TOTAL ...
                        const realTotal = parseNum(cols[5]);
                        const objTotal  = parseNum(cols[6]);
                        realMonthly[mi] = realTotal;
                        objMonthly[mi]  = objTotal;
                    }else if(key === 'hot'){
                        // Estructura (según DESGLOSE VENTAS HOTELES_NACIONAL 2025_FINAL.csv):
                        // MES; MELIA; OBJ_MELIA; ; HOTELES; ; OBJ_HOTELES; TOTAL; ; OBJ_TOTAL
                        const realTotal = parseNum(cols[7]);
                        const objTotal  = parseNum(cols[9]) || (parseNum(cols[2]) + parseNum(cols[6]));
                        realMonthly[mi] = realTotal;
                        objMonthly[mi]  = objTotal;
                    }else if(key === 'car'){
                        // Estructura (según DESGLOSE VENTAS_CARAMELOSNACIONAL 2025_FINAL.csv):
                        // MES; CARAMELOS; OBJETIVO CARAMELOS
                        const realTotal = parseNum(cols[1]);
                        const objTotal  = parseNum(cols[2]);
                        realMonthly[mi] = realTotal;
                        objMonthly[mi]  = objTotal;
                    }
                }

                const realC1 = realMonthly.slice(0,4).reduce((a,b)=>a+b,0);
                const realC2 = realMonthly.slice(4,8).reduce((a,b)=>a+b,0);
                const realC3 = realMonthly.slice(8,12).reduce((a,b)=>a+b,0);

                const objC1 = objMonthly.slice(0,4).reduce((a,b)=>a+b,0);
                const objC2 = objMonthly.slice(4,8).reduce((a,b)=>a+b,0);
                const objC3 = objMonthly.slice(8,12).reduce((a,b)=>a+b,0);

                const realTotal = realC1 + realC2 + realC3;
                const objTotal  = objC1 + objC2 + objC3;

                STATE.objectives.data = STATE.objectives.data || {};
                STATE.objectives.data[key] = {
                    realMonthly, objMonthly,
                    realCuatr: {c1:realC1,c2:realC2,c3:realC3},
                    objCuatr:  {c1:objC1,c2:objC2,c3:objC3},
                    realTotal, objTotal
                };

                // Compat (legacy): STATE.objectives[key] sigue siendo "REAL" para que no rompa nada
                STATE.objectives[key] = realTotal;

                // Para mini-charts legacy
                STATE.objectives.breakdown = STATE.objectives.breakdown || {};
                STATE.objectives.breakdown[key] = {c1:realC1,c2:realC2,c3:realC3};

                STATE.objectives.monthly = STATE.objectives.monthly || {};
                STATE.objectives.monthly[key] = realMonthly;

                saveState();
                updateUI();
                renderMiniCharts();
                renderObjectiveCharts();

                alert(`✅ Carga ${key.toUpperCase()} OK: Real ${formatMoney(realTotal)} | Obj ${formatMoney(objTotal)}`);
                return;
            }

            // === FALLBACK LEGACY (sumatorio de filas por keyword) ===
            let cData = {c1:0, c2:0, c3:0};
            let monthly = new Array(12).fill(0);
            let headerRowIdx = -1;

            for(let i=0; i<lines.length; i++) {
                const row = (lines[i] || '').toLowerCase();
                if(row.includes('enero')) { headerRowIdx = i; break; }
            }
            if(headerRowIdx === -1) {
                alert("⚠️ Error: No se encontró la columna 'ENERO'. Revisa el archivo.");
                return;
            }

            const headerCols = lines[headerRowIdx].split(delim).map(c => c.trim().replace(/"/g, '').toLowerCase());
            const months = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
            const monthIdxs = months.map(m => headerCols.indexOf(m));

            const rowMatches = (rawRow) => {
                if(!kwList.length) return true;
                const rr = (rawRow || '').toLowerCase();
                return kwList.some(k => rr.includes(k));
            };

            for(let i = headerRowIdx + 1; i < lines.length; i++) {
                const rawRow = lines[i];
                if(!rawRow) continue;
                if(!rowMatches(rawRow)) continue;

                const row = rawRow.split(delim).map(c => c.trim());
                if(row.length < 2) continue;
                if((row[0]||'').toLowerCase() === 'total') continue;

                for(let mi=0; mi<12; mi++) {
                    const idx = monthIdxs[mi];
                    if(idx === -1) continue;
                    monthly[mi] += parseNum(row[idx]);
                }
            }

            const c1 = monthly.slice(0,4).reduce((a,b)=>a+b,0);
            const c2 = monthly.slice(4,8).reduce((a,b)=>a+b,0);
            const c3 = monthly.slice(8,12).reduce((a,b)=>a+b,0);

            cData.c1 = c1; cData.c2 = c2; cData.c3 = c3;
            const totalSum = c1 + c2 + c3;

            STATE.objectives[key] = totalSum;
            STATE.objectives.breakdown = STATE.objectives.breakdown || {};
            STATE.objectives.breakdown[key] = cData;

            STATE.objectives.monthly = STATE.objectives.monthly || {};
            STATE.objectives.monthly[key] = monthly;

            saveState();
            updateUI();
            renderMiniCharts();
            renderObjectiveCharts();

            alert(`✅ Carga ${key.toUpperCase()} OK: ${formatMoney(totalSum)}`);
        }catch(err){
            console.error('loadObjectiveCSV error', err);
            alert("⚠️ Error leyendo el CSV. Revisa formato/encoding.");
        }
    };
    reader.readAsText(file, 'ISO-8859-1');
};

// --- RESTO DEL CÓDIGO (ESTABLE) ---

function loadBillingFile(event){
    const file = event.target.files && event.target.files[0];
    if(!file) return;

    const name = (file.name||'').toLowerCase();
    const isCSV = name.endsWith('.csv');

    // Si XLSX no está aún cargado y el usuario sube Excel, intentamos esperar un pelín.
    const tryParseExcel = async () => {
        if(typeof XLSX === 'undefined'){
            // fallback: pedir CSV
            alert('⚠️ No se ha cargado el lector Excel (XLSX). Prueba de nuevo en 3 segundos o sube CSV.');
            return;
        }
        const data = await file.arrayBuffer();
        const wb = XLSX.read(data, { type:'array' });
        const sheetName = wb.SheetNames[0];
        const ws = wb.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json(ws, { defval:'', raw:false });
        const parsed = parseBillingRows(rows);
        STATE.billing = parsed;
        saveBillingMeta();
        saveState();
        renderBilling();
        alert(`✅ FACTURACIÓN: ${parsed.length} facturas cargadas.`);
    };

    if(isCSV){
        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target.result || '';
            const parsed = parseBillingCSV(text);
            STATE.billing = parsed;
            saveBillingMeta();
            saveState();
            renderBilling();
            alert(`✅ FACTURACIÓN: ${parsed.length} facturas cargadas.`);
        };
        reader.readAsText(file, 'ISO-8859-1');
    }else{
        tryParseExcel();
    }
}

function parseBillingCSV(text){
    const lines = String(text||'').split(/\r\n|\n/).filter(Boolean);
    if(!lines.length) return [];
    const delim = lines[0].includes(';') ? ';' : ',';

    // buscar header
    let startIdx = lines.findIndex(l => l.toLowerCase().includes('factura') && (l.toLowerCase().includes('cliente') || l.toLowerCase().includes('nombre') || l.toLowerCase().includes('tercero')));
    if(startIdx === -1) startIdx = 0;

    const headers = splitCSVLine(lines[startIdx], delim).map(h => String(h||'').trim());
    const rows = lines.slice(startIdx+1).map(line => {
        const cols = splitCSVLine(line, delim);
        const obj = {};
        headers.forEach((h,i)=> obj[h] = cols[i] ?? '');
        return obj;
    });
    return parseBillingRows(rows);
}

function normKey(k){
    return String(k||'').toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/\s+/g,' ')
      .trim();
}
function pick(obj, candidates){
    const map = {};
    Object.keys(obj||{}).forEach(k => map[normKey(k)] = obj[k]);
    for(const c of candidates){
        const v = map[normKey(c)];
        if(v !== undefined && v !== null && String(v).trim() !== '') return String(v).trim();
    }
    return '';
}
function parseMoney(v){
    const s = String(v||'').replace(/\s/g,'').replace(/[€]/g,'');
    if(!s) return 0;
    // 1.234,56 o 1,234.56
    const hasComma = s.includes(',');
    const hasDot = s.includes('.');
    let n = s;
    if(hasComma && hasDot){
        // si la coma va al final como decimal
        if(s.lastIndexOf(',') > s.lastIndexOf('.')){
            n = s.replace(/\./g,'').replace(',', '.');
        }else{
            n = s.replace(/,/g,'');
        }
    }else if(hasComma && !hasDot){
        n = s.replace(/\./g,'').replace(',', '.');
    }else{
        n = s.replace(/,/g,'');
    }
    const out = parseFloat(n);
    return Number.isFinite(out) ? out : 0;
}
function parseYearFromRow(r){
    const id = String(r.id||'');
    const m = id.match(/(19|20)\d{2}/);
    if(m) return m[0];
    const d = String(r.date||r.emit||'');
    const m2 = d.match(/(19|20)\d{2}/);
    if(m2) return m2[0];
    return '';
}
function deriveSerieCategory(factura){
    const f = String(factura||'').trim().toUpperCase();
    const prefix = (f.match(/^[A-Z]{2}/)||[''])[0];
    if(prefix === 'EA') return { serie:'EA', category:'Export' };
    if(prefix === 'FN') return { serie:'FN', category:'Nacional' };
    if(prefix) return { serie: prefix, category:'Hoteles' };
    return { serie:'', category:'' };
}

const BILLING_META_KEY = 'cch_billing_meta_v1';
let BILLING_META = null;
function loadBillingMeta(){
    if(BILLING_META) return BILLING_META;
    try{
        BILLING_META = JSON.parse(localStorage.getItem(BILLING_META_KEY) || '{}') || {};
    }catch(e){ BILLING_META = {}; }
    return BILLING_META;
}
function saveBillingMeta(){
    try{
        localStorage.setItem(BILLING_META_KEY, JSON.stringify(loadBillingMeta()));
    }catch(e){}
}
function billingKey(row){
    return `${row.id||''}||${row.client||''}`.toLowerCase();
}

function parseBillingRows(rawRows){
    const meta = loadBillingMeta();
    const out = [];
    (rawRows||[]).forEach(o => {
        const factura = pick(o, ['Factura','Nº Factura','Numero Factura','N_Factura','Factura Nº','Doc','Documento']);
        const cliente = pick(o, ['Cliente','Nombre','Tercero','Razón social','Razon social','Empresa']);
        const comercial = pick(o, ['Comercial','Vendedor','Agente','Responsable','Nombre Comercial']);
        const emision = pick(o, ['Emisión','Emision','Fecha','Fecha emisión','Fecha Emisión','Fecha Doc','F. Emisión','F Emision']);
        const venc = pick(o, ['Vencimiento','Vto','Fecha vto','Fecha Vto','F. Vto','F Vto','Venc']);
        const importe = pick(o, ['Pendiente','Importe pendiente','Imp. pendiente','Importe Pdte','Saldo','Importe','Total']);
        if(!factura && !cliente && !importe) return;

        const serieInfo = deriveSerieCategory(factura);
        const row = {
            id: factura,
            client: cliente,
            agent: comercial,
            emit: emision,
            vto: venc,
            amount: parseMoney(importe),
            year: '',
            serie: serieInfo.serie,
            serieCategory: serieInfo.category,
            pending: true,
            reclaimed: false,
            payApprox: '',
            notes: pick(o, ['Descripción','Descripcion','Detalle','Observaciones','Observacion','Obs'])
        };
        row.year = parseYearFromRow(row) || '';
        const k = billingKey(row);
        const st = meta[k] || {};
        if(typeof st.pending === 'boolean') row.pending = st.pending;
        if(typeof st.reclaimed === 'boolean') row.reclaimed = st.reclaimed;
        if(st.payApprox) row.payApprox = st.payApprox;

        // default: si importe 0, la descartamos
        if(row.amount <= 0) return;
        out.push(row);
    });
    // ordenar por importe desc
    out.sort((a,b)=> (b.amount||0)-(a.amount||0));
    // poblar años selector
    try{ populateBillingYears(out); }catch(e){}
    return out;
}

function populateBillingYears(rows){
    const sel = document.getElementById('bill-year');
    if(!sel) return;
    const years = Array.from(new Set((rows||[]).map(r=>r.year).filter(Boolean))).sort();
    const cur = sel.value;
    sel.innerHTML = '<option value="">Todos</option>' + years.map(y=>`<option value="${y}">${y}</option>`).join('');
    if(years.includes(cur)) sel.value = cur;
}

function initBillingUI(){
    const fsBtn = document.getElementById('btn-fact-fullscreen');
    const view = document.getElementById('view-facturacion');
    if(fsBtn && view){
        fsBtn.onclick = () => view.classList.toggle('facturacion-fullscreen');
    }
    ['bill-search','bill-serie','bill-year','bill-sales','bill-only-pending','bill-only-reclaimed'].forEach(id=>{
        const el = document.getElementById(id);
        if(el) el.addEventListener('input', () => renderBilling());
        if(el) el.addEventListener('change', () => renderBilling());
    });
}

function renderBilling(){
    const tbody = document.getElementById('tbody-billing');
    if(!tbody) return;

    const q = String((document.getElementById('bill-search')||{}).value||'').toLowerCase().trim();
    const serieCat = String((document.getElementById('bill-serie')||{}).value||'');
    const year = String((document.getElementById('bill-year')||{}).value||'');
    const agent = String((document.getElementById('bill-sales')||{}).value||'');
    const onlyPending = !!((document.getElementById('bill-only-pending')||{}).checked);
    const onlyReclaimed = !!((document.getElementById('bill-only-reclaimed')||{}).checked);

    const rows = (STATE.billing||[]).filter(r=>{
        if(serieCat && r.serieCategory !== serieCat) return false;
        if(year && String(r.year) !== String(year)) return false;
        if(agent && String(r.agent||'') !== agent) return false;
        if(onlyPending && !r.pending) return false;
        if(onlyReclaimed && !r.reclaimed) return false;
        if(q){
            const hay = `${r.id} ${r.client} ${r.notes} ${r.agent} ${r.serie} ${r.year}`.toLowerCase();
            if(!hay.includes(q)) return false;
        }
        return true;
    });

    // KPIs
    const count = rows.length;
    const amount = rows.reduce((s,r)=>s+(r.amount||0),0);
    const reclaimed = rows.filter(r=>r.reclaimed).length;
    const setTxt = (id,val)=>{ const el=document.getElementById(id); if(el) el.innerText = val; };
    setTxt('bill-kpi-count', String(count));
    setTxt('bill-kpi-amount', formatMoney(amount));
    setTxt('bill-kpi-reclaimed', String(reclaimed));

    // Summary by agent
    const byAgent = {};
    rows.forEach(r=>{
        const k = r.agent || 'Sin comercial';
        if(!byAgent[k]) byAgent[k] = { count:0, amount:0 };
        byAgent[k].count += 1;
        byAgent[k].amount += (r.amount||0);
    });
    const summary = document.getElementById('bill-summary');
    if(summary){
        const entries = Object.entries(byAgent).sort((a,b)=> b[1].amount - a[1].amount);
        summary.innerHTML = entries.map(([name, v]) => `
          <div class="bill-summary-row">
            <div class="name">${escapeHtml(name)}</div>
            <div class="meta">${v.count} · ${formatMoney(v.amount)}</div>
          </div>`).join('') || '<div style="color:#64748b;font-weight:700">Sin datos (aplica filtros o carga Excel).</div>';
    }

    // Chart
    try{
        const ctx = document.getElementById('bill-chart');
        if(ctx){
            const labels = Object.keys(byAgent);
            const data = labels.map(k=> byAgent[k].amount);
            if(charts.billChart) charts.billChart.destroy();
            charts.billChart = safeChart(ctx, {
                type: 'bar',
                data: { labels, datasets: [{ label: '€ pendientes', data }] },
                options: { responsive:true, plugins:{ legend:{ display:false } }, scales:{ y:{ ticks:{ callback:(v)=> v>=1000? (v/1000)+'k': v } } } }
            });
        }
    }catch(e){}

    // Table
    const meta = loadBillingMeta();
    tbody.innerHTML = rows.map((r, i)=>{
        const k = billingKey(r);
        const st = meta[k] || {};
        const reclaimedChecked = (typeof st.reclaimed === 'boolean' ? st.reclaimed : r.reclaimed) ? 'checked' : '';
        const pendingChecked = (typeof st.pending === 'boolean' ? st.pending : r.pending) ? 'checked' : '';
        const payApprox = escapeAttr(st.payApprox || r.payApprox || '');
        const status = (typeof st.pending === 'boolean' ? st.pending : r.pending) ? 'Pendiente' : 'Pagada';
        return `
          <tr class="bill-row" data-k="${escapeAttr(k)}">
            <td><button class="bill-expand-btn" type="button" onclick="toggleBillRow(this)"><i class="fa-solid fa-chevron-down"></i></button></td>
            <td style="font-weight:800">${escapeHtml(r.id)}</td>
            <td>${escapeHtml(r.client)}</td>
            <td>${escapeHtml(r.year||'')}</td>
            <td><span class="bill-pill">${escapeHtml(r.serieCategory||r.serie||'')}</span></td>
            <td>${escapeHtml(r.agent||'')}</td>
            <td>${escapeHtml(r.emit||'')}</td>
            <td>${escapeHtml(r.vto||'')}</td>
            <td style="font-weight:900;color:var(--red)">${formatMoney(r.amount||0)}</td>
            <td><input type="checkbox" ${reclaimedChecked} onchange="setBillMeta('${escapeAttr(k)}','reclaimed', this.checked)" /></td>
            <td><input type="date" value="${payApprox}" onchange="setBillMeta('${escapeAttr(k)}','payApprox', this.value)" style="height:34px;border-radius:10px;border:1px solid rgba(148,163,184,.45);padding:0 10px" /></td>
            <td><label class="chip" style="padding:6px 10px"><input type="checkbox" ${pendingChecked} onchange="setBillMeta('${escapeAttr(k)}','pending', this.checked); renderBilling();" /><span>${status}</span></label></td>
          </tr>
          <tr class="bill-row-details">
            <td colspan="12">
              <div class="bill-details-box">
                <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:space-between">
                  <div style="font-weight:900">${escapeHtml(r.client)} · <span style="color:#64748b;font-weight:800">${escapeHtml(r.id)}</span></div>
                  <div style="display:flex;gap:8px;flex-wrap:wrap">
                    <span class="bill-pill">Serie: ${escapeHtml(r.serie||'-')}</span>
                    <span class="bill-pill">Vto: ${escapeHtml(r.vto||'-')}</span>
                    <span class="bill-pill">€: ${formatMoney(r.amount||0)}</span>
                  </div>
                </div>
                ${r.notes ? `<div style="margin-top:10px;color:#334155"><b>Detalle:</b> ${escapeHtml(r.notes)}</div>` : ''}
              </div>
            </td>
          </tr>
        `;
    }).join('') || `<tr><td colspan="12" style="padding:16px;color:#64748b;font-weight:700">Carga el Excel/CSV para ver facturas pendientes.</td></tr>`;
}

window.toggleBillRow = function(btn){
    const tr = btn.closest('tr');
    if(!tr) return;
    tr.classList.toggle('bill-expanded');
};

window.setBillMeta = function(key, field, value){
    const meta = loadBillingMeta();
    meta[key] = meta[key] || {};
    meta[key][field] = value;
    saveBillingMeta();
};

async function loadCSV(event, type) {
    const file = event.target.files[0];
    if(!file) return;

    // XLSX soportado (si el usuario lo sube)
    if(file.name.toLowerCase().endsWith('.xlsx')) {
        const ok = await ensureXLSX();
        if(!ok){ alert('No se pudo cargar el lector XLSX. Guarda como CSV o revisa conexión.'); event.target.value=''; return; }
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
        const data = parseRowsObject(rows, type);
        STATE[type] = data; saveState(); updateUI(); alert(`✅ ${data.length} registros.`);
        event.target.value = '';
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        const text = e.target.result || '';
        const data = parseRobust(text, type);
        STATE[type] = data; saveState(); updateUI(); alert(`✅ ${data.length} registros.`);
        event.target.value = '';
    };
    // Primero intentamos UTF-8; si hay caracteres raros el parser seguirá funcionando
    reader.readAsText(file, 'utf-8');
}


function splitCSVLine(line, delim){
    // Split CSV/SSV line respecting quotes. Handles doubled quotes.
    const out = [];
    let cur = '';
    let inQ = false;
    for(let i=0;i<line.length;i++){
        const ch = line[i];
        if(ch === '"'){
            if(inQ && line[i+1] === '"'){ cur += '"'; i++; }
            else { inQ = !inQ; }
        } else if(!inQ && ch === delim){
            out.push(cur); cur = '';
        } else {
            cur += ch;
        }
    }
    out.push(cur);
    return out;
}

async function ensureXLSX(){
    if(window.XLSX) return true;
    return new Promise((resolve) => {
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';
        s.onload = () => resolve(true);
        s.onerror = () => resolve(false);
        document.head.appendChild(s);
    });
}
function parseRobust(text, type) {
    const lines = text.trim().split(/\r\n|\n/);
    if (lines.length < 2) return [];
    const delim = lines[0].includes(';') ? ';' : ',';
    const headers = splitCSVLine(lines[0], delim).map(h => h.trim().replace(/"/g, '').toLowerCase());
    const find = (k) => headers.findIndex(h => k.some(x => h.includes(x)));
    const idx = { client: find(['cliente','nombre']), amount: find(['total','importe']), date: find(['fecha','inicio']), agent: find(['agente','comercial']), status: find(['estado','situacion']), desc: find(['descrip']) };
    return lines.slice(1).map((line, i) => {
        const row = splitCSVLine(line, delim);
        if(row.length < 2) return null;
        const val = (c) => (c > -1 && row[c]) ? row[c].trim().replace(/"/g, '') : '';
        return { client: val(idx.client)||'S/N', amount: parseFloat(val(idx.amount).replace(/\./g,'').replace(',','.'))||0, date: val(idx.date)||'01/01/2026', agent: val(idx.agent)||'S/A', status: val(idx.status)||'Pendiente', desc: val(idx.desc)||'-', id: i, notes: (STATE[type]&&STATE[type][i])?STATE[type][i].notes:'' };
    }).filter(x => x);
}


function parseRowsObject(rows, type){
    // rows: array of objects from XLSX. Normalize header keys.
    if(!rows || !rows.length) return [];
    const normKey = (k) => String(k||'').trim().replace(/"/g,'').toLowerCase();
    const keys = Object.keys(rows[0]||{}).map(normKey);
    const findKey = (cands) => {
        for(const k of Object.keys(rows[0]||{})){
            const nk = normKey(k);
            if(cands.some(c => nk.includes(c))) return k;
        }
        return null;
    };
    const kClient = findKey(['cliente','nombre']);
    const kAmount = findKey(['total','importe']);
    const kDate   = findKey(['fecha','inicio']);
    const kAgent  = findKey(['agente','comercial']);
    const kStatus = findKey(['estado','situacion']);
    const kDesc   = findKey(['descrip','concepto','detalle']);
    return rows.map((r,i) => {
        const v = (k) => k ? String(r[k] ?? '').trim() : '';
        const amount = parseFloat(v(kAmount).replace(/\./g,'').replace(',','.')) || 0;
        return { client: v(kClient)||'S/N', amount, date: v(kDate)||'01/01/2026', agent: v(kAgent)||'S/A',
                 status: v(kStatus)||'Pendiente', desc: v(kDesc)||'-', id: i, notes: (STATE[type]&&STATE[type][i])?STATE[type][i].notes:'' };
    });
}
function updateUI() {
    const q = String(window.__CCH_SEARCH_Q || '').toLowerCase().trim();
    const fSerie = String(window.__CCH_FILTER_SERIE || 'all');
    const fAgent = String(window.__CCH_FILTER_AGENT || 'Todos');

    const matchSearch = (x) => {
        if(!q) return true;
        return (String(x.client||'').toLowerCase().includes(q) ||
                String(x.desc||'').toLowerCase().includes(q) ||
                String(x.agent||'').toLowerCase().includes(q) ||
                String(x.serie||'').toLowerCase().includes(q) ||
                String(x.id||'').toLowerCase().includes(q));
    };
    const matchSerie = (x) => {
        if(!fSerie || fSerie === 'all') return true;
        const s = String(x.bucket||x.serie||x.section||'').toLowerCase();
        return s.includes(String(fSerie).toLowerCase());
    };
    const matchAgent = (x) => {
        if(!fAgent || fAgent === 'Todos') return true;
        return String(x.agent||'').toLowerCase().includes(String(fAgent).toLowerCase());
    };
    const applyFilters = (arr) => (arr||[]).filter(x => matchSearch(x) && matchSerie(x) && matchAgent(x));

    // KPIs: por defecto tiran de Analítica (2026), y si no hay datos, de las listas cargadas.
    const anOrders26 = STATE.analytics?.ordersByYear?.['2026'];
    const anOffers26 = STATE.analytics?.offersByYear?.['2026'];
    const kpiOrdCount = (anOrders26 && Number.isFinite(anOrders26.count)) ? anOrders26.count : (STATE.orders||[]).length;
    const kpiOrdTotal = (anOrders26 && Number.isFinite(anOrders26.total)) ? anOrders26.total : (STATE.orders||[]).reduce((a,b)=>a+(b.amount||0),0);
    const kpiOffCount = (anOffers26 && Number.isFinite(anOffers26.count)) ? anOffers26.count : (STATE.offers||[]).length;
    const kpiOffTotal = (anOffers26 && Number.isFinite(anOffers26.total)) ? anOffers26.total : (STATE.offers||[]).reduce((a,b)=>a+(b.amount||0),0);
    const elOffC = document.getElementById('kpi-off-count');
    const elOffT = document.getElementById('kpi-off-amount');
    const elOrdC = document.getElementById('kpi-ord-count');
    const elOrdT = document.getElementById('kpi-ord-amount');
    if(elOffC) elOffC.innerText = String(kpiOffCount);
    if(elOffT) elOffT.innerText = formatMoney(kpiOffTotal);
    if(elOrdC) elOrdC.innerText = String(kpiOrdCount);
    if(elOrdT) elOrdT.innerText = formatMoney(kpiOrdTotal);
    const miniOff = document.getElementById('mini-off');
    const miniOrd = document.getElementById('mini-ord');
    if(miniOff) miniOff.innerText = formatMoney(kpiOffTotal);
    if(miniOrd) miniOrd.innerText = formatMoney(kpiOrdTotal);

    // Listas: sí aplican filtros del dashboard
    ['offers','orders'].forEach(t => {
        const arr = applyFilters(STATE[t]);
        const list = document.getElementById(`list-${t}`);
        if(list){
            if(arr.length){
                list.innerHTML = arr.slice(0,30).map((item, i) => `<div class="item-card" onclick="openDetail('${t}', ${i})"><div class="item-tit"><span>${item.client}</span> <strong>${formatMoney(item.amount)}</strong></div><div class="item-desc">${item.desc||'-'}</div></div>`).join('');
            } else {
                // No tocamos el placeholder de subida si no hay datos
                if(STATE[t].length){ list.innerHTML = `<div style="padding:18px;opacity:.7">Sin resultados con los filtros actuales.</div>`; }
            }
        }
    });
    if(STATE.rfqs.length) {
        document.getElementById('kpi-rfq-count').innerText = STATE.rfqs.length;
        const listRfq = document.getElementById('list-rfqs');
        if(listRfq) listRfq.innerHTML = STATE.rfqs.slice(0,30).map((item, i) => `<div class="item-card" onclick="openDetail('rfqs', ${i})"><div class="item-tit"><span>${item.client}</span> <span class="status-pill">${item.status}</span></div><div class="item-desc">${item.desc}</div></div>`).join('');
    }
    ['nac','exp','hot','car'].forEach(k => {
        const elReal = document.getElementById(`val-${k}`);
        const elObj  = document.getElementById(`obj-${k}`);
        const data = (STATE.objectives && STATE.objectives.data && STATE.objectives.data[k]) ? STATE.objectives.data[k] : null;
        const realVal = (data && Number.isFinite(data.realTotal)) ? data.realTotal : STATE.objectives[k];
        const objVal  = (data && Number.isFinite(data.objTotal))  ? data.objTotal  : null;

        if(elReal) elReal.innerText = formatMoney(realVal);
        if(elObj && objVal !== null) elObj.innerText = formatMoney(objVal);
    });
    renderBilling();

    try{ updateStrategicPanel(); }catch(e){}
}

// GANTT
function renderGantt() {
    const c = document.getElementById('gantt-container');
    const d = STATE.orders.length ? STATE.orders.slice(0,12) : [{client:'Sin Pedidos', date:'2026-01-01'}];
    c.innerHTML = d.map((o, i) => `<div class="gantt-row"><div class="gantt-controls"><strong>${o.client}</strong><div style="display:flex;gap:4px"><input type="date" id="start-${i}" value="${o.date_start||'2026-02-01'}" onchange="updateGanttDates(${i})"><input type="date" id="end-${i}" value="${o.date_end||'2026-04-01'}" onchange="updateGanttDates(${i})"></div><button style="font-size:9px" onclick="editNote(${i})">📝 ${o.notes?'Ver':'Nota'}</button></div><div class="gantt-bar-area"><div id="bar-${i}" class="gantt-bar-vis" style="left:10%; width:20%" onmousedown="dragGantt(event, this, ${i})">Prod</div><i class="fa-solid fa-bell gantt-bell ${o.alarm?'active':''}" onclick="toggleAlarm(${i})"></i></div></div>`).join('');
    setTimeout(() => { d.forEach((o, i) => updateGanttDates(i, true)); }, 50);
}
window.updateGanttDates = (i, onlyVisual=false) => {
    const sVal = document.getElementById(`start-${i}`).value;
    const eVal = document.getElementById(`end-${i}`).value;
    if(!onlyVisual) { STATE.orders[i].date_start = sVal; STATE.orders[i].date_end = eVal; saveState(); }
    const s = new Date(sVal); const e = new Date(eVal);
    const startY = new Date('2026-01-01');
    const msYear = 1000 * 60 * 60 * 24 * 365;
    const left = ((s - startY) / msYear) * 100;
    const width = ((e - s) / msYear) * 100;
    const bar = document.getElementById(`bar-${i}`);
    if(bar) { bar.style.left = Math.max(0, left) + '%'; bar.style.width = Math.max(1, width) + '%'; }
};
window.editNote = (i) => { const txt = prompt("Nota:", STATE.orders[i].notes||""); if(txt!==null) { STATE.orders[i].notes = txt; saveState(); } };
function dragGantt(e, el, i) { /* Same */ }
window.toggleAlarm = (i) => { STATE.orders[i].alarm = !STATE.orders[i].alarm; saveState(); renderGantt(); };

window.startVoiceSearch = () => {
    const input = document.getElementById('global-search');
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if(!SpeechRecognition){
        alert('Micrófono no disponible en este navegador (SpeechRecognition).');
        return;
    }
    try{
        const rec = new SpeechRecognition();
        rec.lang = 'es-ES';
        rec.interimResults = false;
        rec.maxAlternatives = 1;
        rec.onresult = (ev) => {
            const text = ev.results && ev.results[0] && ev.results[0][0] ? ev.results[0][0].transcript : '';
            if(input){
                input.value = text;
                window.__CCH_SEARCH_Q = String(text||'').toLowerCase().trim();
                updateUI();
            }
        };
        rec.onerror = (e) => {
            console.warn('SpeechRecognition error', e);
            alert('No se pudo iniciar el micrófono (permiso o compatibilidad).');
        };
        rec.start();
    }catch(err){
        console.error(err);
        alert('No se pudo iniciar el micrófono (permiso o compatibilidad).');
    }
};

function filterGlobal() {
    const input = document.getElementById('global-search');
    const q = String(input ? input.value : '').toLowerCase().trim();
    window.__CCH_SEARCH_Q = q;
    updateUI();
    // Si estamos en listas (tabla), repintamos
    const view = location.hash.replace('#','') || '';
    if(view.includes('rfq') || view.includes('offer') || view.includes('order')){
        try{ renderTable(view); }catch(e){}
    }
}

// ================================
// ANALÍTICA · Pedidos multi-año (xlsx/csv)
// Reglas:
// - Solo EstadoDescrip = COMPLETADO (incluye 'COMPLET')
// - Solo totalIVA > 0
// - Serie: EA=EXPORT, FV/FN=NACIONAL, resto=HOTELES, (heurística) CA*/CAR*=CARAMELOS
// Colores por año (fijos): 2024 azul, 2025 verde, 2026 naranja
// ================================

function initAnalyticsHandlers(){
    // Toggle Pedidos / Ofertas
    const tabOrders = document.getElementById('an2-tab-orders');
    const tabOffers = document.getElementById('an2-tab-offers');
    const yearLabel = document.getElementById('an2-year-label');
    const setModeUI = (mode) => {
        STATE.analytics.mode = mode;
        if(tabOrders) tabOrders.classList.toggle('active', mode==='orders');
        if(tabOffers) tabOffers.classList.toggle('active', mode==='offers');
        const uploadBtn = document.getElementById('an2-upload-btn');
        if(yearLabel) yearLabel.textContent = mode==='offers' ? 'AÑO OFERTAS' : 'AÑO PEDIDOS';
        if(uploadBtn) uploadBtn.innerHTML = mode==='offers'
            ? '<i class="fa-solid fa-cloud-arrow-up"></i> Subir OFERTAS (año)'
            : '<i class="fa-solid fa-cloud-arrow-up"></i> Subir PEDIDOS (año)';
        const status = document.getElementById('an2-status');
        if(status){
            status.textContent = mode==='offers'
                ? 'Sin datos. Sube ofertas por año (xlsx/csv) → se comparan automáticamente.'
                : 'Sin datos. Sube pedidos por año (xlsx/csv) → se comparan automáticamente.';
        }
    };
    if(tabOrders) tabOrders.onclick = () => { setModeUI('orders'); saveState(); renderAnalytics(); updateUI(); };
    if(tabOffers) tabOffers.onclick = () => { setModeUI('offers'); saveState(); renderAnalytics(); updateUI(); };

    const btn = document.getElementById('an2-upload-btn');
    const file = document.getElementById('an2-file');
    const yearSel = document.getElementById('an2-year');
    const addYear = document.getElementById('an2-add-year');
    const clear = document.getElementById('an2-clear');
    const expBtn = document.getElementById('an2-export-btn');
    // Inicializa UI segun estado
    setModeUI(STATE.analytics.mode || 'orders');

    if(btn && file){
        btn.onclick = () => file.click();
        file.onchange = async () => {
            const files = Array.from(file.files || []);
            if(!files.length) return;
            const forcedYear = yearSel ? String(yearSel.value || '').trim() : '';
            try{
                for (const f of files){
                    const mode = STATE.analytics.mode || 'orders';
                    const rows = (mode==='offers') ? await readOffersFile(f) : await readOrdersFile(f);
                    const detectedYear = (mode==='offers')
                        ? detectYearFromOffers(rows, forcedYear, f && f.name)
                        : detectYearFromOrders(rows, forcedYear, f && f.name);
                    const norm = (mode==='offers') ? normalizeOffers(rows, detectedYear) : normalizeOrders(rows, detectedYear);

                    const bucket = (mode==='offers') ? STATE.analytics.offersByYear : STATE.analytics.ordersByYear;
                    const existing = bucket[detectedYear];
                    bucket[detectedYear] = mergeNormalizedOrders(existing, norm);
                }
                saveState();
                renderAnalytics();
                updateUI();
	            }catch(err){
	                console.error(err);
	                const msg = (err && err.message) ? err.message : String(err || 'Error desconocido');
	                alert('No se ha podido leer el fichero.\n\nDetalle: ' + msg + '\n\nSi es XLSX, asegúrate de que no está protegido. Si es CSV, revisa el separador (;) o (,) y la cabecera.');
            }finally{
                file.value = '';
            }
        };
    }
    if(addYear && yearSel){
        addYear.onclick = () => {
            const y = prompt('Añadir año (ej: 2019):', '').trim();
            if(!y) return;
            if(!/^\d{4}$/.test(y)) return alert('Año no válido. Usa formato YYYY (ej: 2019).');
            const exists = [...yearSel.options].some(o => o.value === y);
            if(!exists){
                const opt = document.createElement('option');
                opt.value = y;
                opt.textContent = y;
                yearSel.appendChild(opt);
            }
            yearSel.value = y;
        };
    }
    if(clear){
        clear.onclick = () => {
            if(!confirm('¿Borrar los años cargados en Analítica?')) return;
            if((STATE.analytics.mode||'orders') === 'offers') STATE.analytics.offersByYear = {};
            else STATE.analytics.ordersByYear = {};
            saveState();
            renderAnalytics();
            updateUI();
        };
    }

    if(expBtn){
        expBtn.onclick = () => {
            try{ exportHighValueClients(); }
            catch(e){ console.error(e); alert('No se ha podido exportar.'); }
        };
    }
}

// Detecta el año desde un archivo de pedidos.
// Prioridad: columna de Año -> columna Fecha -> fallbackYear (selector)
function detectYearFromOrders(rows, fallbackYear, filename){
    // 0) Nombre de archivo
    const name = String(filename||'');
    const mName = name.match(/(19|20)\d{2}/);
    if(mName) return mName[0];

    const sample = (Array.isArray(rows) && rows.length) ? rows.slice(0, 200) : [];
    // Intento 1: columnas con año
    const yearKeysRe = /(\baño\b|year)/i;
    for(const r of sample){
        const k = Object.keys(r||{}).find(x => yearKeysRe.test(String(x)));
        if(k){
            const v = String(r[k]??'').trim();
            const m = v.match(/(19|20)\d{2}/);
            if(m) return m[0];
        }
    }
    // Intento 2: fecha
    const dateKeyRe = /(fecha|date)/i;
    for(const r of sample){
        const k = Object.keys(r||{}).find(x => dateKeyRe.test(String(x)));
        if(k){
            const d = parseDateFlexible(r[k]);
            if(d && !Number.isNaN(d.getTime())) return String(d.getFullYear());
        }
    }
    // 3) fallback (selector)
    const fb = String(fallbackYear||'').trim();
    if(/^[12]\d{3}$/.test(fb)) return fb;

    // Si no podemos detectarlo, usamos el año actual
    return String(new Date().getFullYear());
}

// Ofertas: misma heurística que pedidos
function detectYearFromOffers(rows, fallbackYear, filename){
    return detectYearFromOrders(rows, fallbackYear, filename);
}

function mergeNormalizedOrders(existing, incoming){
    const toObj = (x) => {
        if(!x) return null;
        if(Array.isArray(x)){
            // Compatibilidad con versiones anteriores
            return x.reduce((acc,it)=> mergeNormalizedOrders(acc, it), null);
        }
        if(x && typeof x === 'object' && Array.isArray(x.rows)) return x;
        return null;
    };

    const a = toObj(existing);
    const b = toObj(incoming);
    if(!a) return b;
    if(!b) return a;

    const year = String(b.year || a.year || new Date().getFullYear());
    const rows = [...(a.rows||[]), ...(b.rows||[])];

    // Recalcula agregados a partir de filas normalizadas
    const byMonth = Array(12).fill(0);
    const bySerie = {};
    const byClient = {};
    let total = 0;
    let count = 0;

    rows.forEach(r => {
        const imp = Number(r.importe)||0;
        if(imp<=0) return;
        total += imp;
        count += 1;
        const dt = r.fecha ? new Date(r.fecha) : null;
        if(dt && !Number.isNaN(dt.getTime())) byMonth[dt.getMonth()] += imp;
        const s = String(r.serie||'').trim() || 'SIN_SERIE';
        bySerie[s] = (bySerie[s]||0) + imp;
        const c = String(r.cliente||'').trim() || 'SIN_CLIENTE';
        byClient[c] = (byClient[c]||0) + imp;
    });

    return { year, rows, total, count, byMonth, bySerie, byClient };
}

function exportHighValueClients(){
  // Section filter (pills). If none selected, we export ALL.
  const secSel = new Set();
  const secN = document.getElementById('an2-sec-nacional');
  const secH = document.getElementById('an2-sec-hoteles');
  const secE = document.getElementById('an2-sec-export');
  const secC = document.getElementById('an2-sec-caramelos');
  if(secN && secN.checked) secSel.add('NACIONAL');
  if(secH && secH.checked) secSel.add('HOTELES');
  if(secE && secE.checked) secSel.add('EXPORT');
  if(secC && secC.checked) secSel.add('CARAMELOS');
    const byYear = (STATE.analytics && STATE.analytics.ordersByYear) ? STATE.analytics.ordersByYear : {};
    const years = Object.keys(byYear).filter(Boolean);
    if(!years.length) return alert('No hay años cargados en Analítica.');

    const fromEl = document.getElementById('an2-from');
    const toEl = document.getElementById('an2-to');
    const minEl = document.getElementById('an2-min');
    const min = parseFloat(minEl && minEl.value ? minEl.value : '3000') || 3000;

    const from = fromEl && fromEl.value ? new Date(fromEl.value + 'T00:00:00') : null;
    const to = toEl && toEl.value ? new Date(toEl.value + 'T23:59:59') : null;

    // 1) Filtra filas por rango de fechas
    const all = [];
    years.forEach(y => {
        const d = byYear[y];
        (d && d.rows ? d.rows : []).forEach(r => {
            const dt = r.fecha ? new Date(r.fecha) : null;
            if(from && (!dt || dt < from)) return;
            if(to && (!dt || dt > to)) return;
            const _sec = String(r.bucket || '').toUpperCase();
            if(secSel.size && _sec && !secSel.has(_sec)) return;
            all.push({
                Año: y,
                Cliente: r.cliente || 'Sin cliente',
                Serie: r.serie || '',
                Sección: r.bucket || '',
                Fecha: dt ? dt.toISOString().slice(0,10) : '',
                Importe: r.amount || 0,
                Observaciones: r.desc || ''
            });
        });
    });
    if(!all.length) return alert('No hay pedidos en el rango seleccionado.');

    // 2) Totales por cliente dentro del rango
    const totByClient = {};
    all.forEach(r => { totByClient[r.Cliente] = (totByClient[r.Cliente]||0) + (r.Importe||0); });
    const allowed = new Set(Object.keys(totByClient).filter(c => totByClient[c] >= min));
    if(!allowed.size) return alert(`No hay clientes por encima de ${min.toLocaleString('es-ES')} € en el rango.`);

    // 3) Filas finales
    const rows = all.filter(r => allowed.has(r.Cliente)).map(r => ({
        Año: r.Año,
        Cliente: r.Cliente,
        Serie: r.Serie,
        Sección: r.Sección,
        Fecha: r.Fecha,
        Importe: r.Importe,
        Observaciones: r.Observaciones
    }));

    // 4) Descarga XLSX (más operativa: columnas anchas, no se solapa el texto)
    const stamp = new Date().toISOString().slice(0,10);
    const baseName = `clientes_mayor_${Math.round(min)}_${stamp}`;

    if(window.XLSX){
        const ws = XLSX.utils.json_to_sheet(rows, {header:['Año','Cliente','Serie','Sección','Fecha','Importe','Observaciones']});
        // Columnas: ancho razonable para que "Observaciones" se lea
        ws['!cols'] = [
            {wch:6},   // Año
            {wch:38},  // Cliente
            {wch:10},  // Serie
            {wch:14},  // Sección
            {wch:14},  // Fecha
            {wch:12},  // Importe
            {wch:90}   // Observaciones
        ];
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Clientes>MIN');
        XLSX.writeFile(wb, `${baseName}.xlsx`);
    } else {
        // Fallback CSV si por cualquier motivo no carga XLSX
        const header = Object.keys(rows[0]);
        const csv = [header.join(';')].concat(rows.map(r => header.map(h => {
            const v = r[h];
            if(h === 'Importe') return String((v||0).toFixed(2)).replace('.',',');
            return String(v ?? '').replace(/\r?\n/g,' ').replace(/;/g,',');
        }).join(';'))).join('\n');
        const blob = new Blob(["\uFEFF"+csv], {type:'text/csv;charset=utf-8'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${baseName}.csv`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    }
}

async function readOrdersFile(file){
    const name = (file.name || '').toLowerCase();
    if(name.endsWith('.csv')){
        const text = await file.text();
        // Prefer SheetJS for CSV too (better delimiter handling). Fallback to internal parser.
        if(window.XLSX){
            try {
                const wb = XLSX.read(text, {type:'string'});
                const sheetName = wb.SheetNames?.[0];
                const ws = wb.Sheets[sheetName];
                const rows = XLSX.utils.sheet_to_json(ws, {defval:'', raw:false});
                if(Array.isArray(rows) && rows.length) return rows;
            } catch(e){
                // ignore and fallback
            }
        }
        return csvToRows(text);
    }
    // XLSX
    const buf = await file.arrayBuffer();
    if(!window.XLSX) throw new Error('XLSX library not loaded');
    const wb = XLSX.read(buf, { type:'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
	// Robust header detection: some XLSX have blank rows or meta rows before the real header.
	const aoa = XLSX.utils.sheet_to_json(ws, { header:1, defval:'' });
	const want = ['cliente','serie','fecha','totaliva','observaciones','observacion','importe','seccion'];
	let headerRow = 0;
	for(let i=0;i<Math.min(10, aoa.length);i++){
	    const row = (aoa[i]||[]).map(x => String(x||'').trim().toLowerCase());
	    const hit = row.filter(v => want.includes(v)).length;
	    const hasClient = row.includes('cliente');
	    const hasDate = row.includes('fecha');
	    if(hit>=2 && hasClient && hasDate){ headerRow=i; break; }
	}
	const headers = (aoa[headerRow]||[]).map(h => String(h||'').trim());
	const out = [];
	for(let r=headerRow+1;r<aoa.length;r++){
	    const row = aoa[r]||[];
	    if(!row.some(v => String(v||'').trim()!=='') ) continue;
	    const obj = {};
	    for(let c=0;c<headers.length;c++){
	        const key = headers[c] || `__col_${c}`;
	        obj[key] = row[c] ?? '';
	    }
	    out.push(obj);
	}
	return out;
}

async function readOffersFile(file){
    // Misma lógica que pedidos pero sin heurística de cabecera tan estricta
    const name = (file.name || '').toLowerCase();
    if(name.endsWith('.csv')){
        const text = await file.text();
        if(window.XLSX){
            try{
                const wb = XLSX.read(text, {type:'string'});
                const ws = wb.Sheets[wb.SheetNames[0]];
                const rows = XLSX.utils.sheet_to_json(ws, {defval:'', raw:false});
                if(Array.isArray(rows) && rows.length) return rows;
            }catch(e){ }
        }
        return csvToRows(text);
    }
    const buf = await file.arrayBuffer();
    if(!window.XLSX) throw new Error('XLSX library not loaded');
    const wb = XLSX.read(buf, {type:'array'});
    const ws = wb.Sheets[wb.SheetNames[0]];
    // Detecta cabecera buscando una fila que contenga al menos Cliente+Fecha o Cliente+Importe
    const aoa = XLSX.utils.sheet_to_json(ws, {header:1, defval:''});
    const want = ['cliente','fecha','importe','total','serie','seccion','observaciones','descripcion'];
    let headerRow = 0;
    for(let i=0;i<Math.min(12, aoa.length);i++){
        const row = (aoa[i]||[]).map(x => String(x||'').trim().toLowerCase());
        const hit = row.filter(v => want.some(w => v.includes(w))).length;
        const hasClient = row.some(v => v.includes('cliente') || v.includes('nombre'));
        const hasDate = row.some(v => v.includes('fecha') || v.includes('date'));
        const hasImp = row.some(v => v.includes('importe') || v.includes('total'));
        if(hit>=2 && hasClient && (hasDate || hasImp)){ headerRow=i; break; }
    }
    const headers = (aoa[headerRow]||[]).map(h => String(h||'').trim());
    const out = [];
    for(let r=headerRow+1;r<aoa.length;r++){
        const row = aoa[r]||[];
        if(!row.some(v => String(v||'').trim()!=='')) continue;
        const obj = {};
        for(let c=0;c<headers.length;c++){
            const key = headers[c] || `__col_${c}`;
            obj[key] = row[c] ?? '';
        }
        out.push(obj);
    }
    return out;
}

// CSV parser (supports quotes + delimiters inside quotes + embedded newlines)
function csvToRows(text){
    const clean = String(text || '').replace(/^\uFEFF/, '');
    if(!clean.trim()) return [];

    // pick delimiter by first line heuristic (supports ; , \t)
    const firstLine = clean.split(/\r\n|\n/)[0] || '';
    const counts = {
        ';': (firstLine.match(/;/g) || []).length,
        ',': (firstLine.match(/,/g) || []).length,
        '\t': (firstLine.match(/\t/g) || []).length,
    };
    const delim = Object.entries(counts)
        .sort((a,b) => b[1]-a[1] || ({';':0, ',':1, '\t':2}[a[0]] - ({';':0, ',':1, '\t':2}[b[0]])))
        [0][0];

    const rows = [];
    let row = [];
    let cur = '';
    let inQ = false;
    for(let i=0;i<clean.length;i++){
        const ch = clean[i];
        const next = clean[i+1];

        if(ch === '"'){
            if(inQ && next === '"'){ // escaped quote
                cur += '"';
                i++;
            }else{
                inQ = !inQ;
            }
            continue;
        }

        if(!inQ && (ch === delim)){
            row.push(cur);
            cur = '';
            continue;
        }

        if(!inQ && (ch === '\n' || ch === '\r')){
            // handle CRLF
            if(ch === '\r' && next === '\n') i++;
            row.push(cur);
            cur = '';
            // ignore empty trailing lines
            if(row.some(c => String(c).trim() !== '')) rows.push(row);
            row = [];
            continue;
        }

        cur += ch;
    }
    // last cell
    if(cur.length || row.length){
        row.push(cur);
        if(row.some(c => String(c).trim() !== '')) rows.push(row);
    }
    if(!rows.length) return [];

    // Strip BOM and normalize header whitespace
    const headers = rows[0].map(h => String(h ?? '').replace(/^\uFEFF/, '').trim());
    return rows.slice(1).map(r => {
        const o = {};
        headers.forEach((h, idx) => o[h] = String(r[idx] ?? '').trim());
        return o;
    });
}

function parseEuroNumber(v){
    if(v === null || v === undefined) return 0;
    let s = String(v).trim();
    if(!s) return 0;
    // Support suffixes like "k" / "mil" / "m" (e.g. "334k€" => 334.000)
    let mult = 1;
    {
        const raw = s.toLowerCase().replace(/\s/g,'').replace(/€/g,'');
        if(/(\d)(k)$/.test(raw) || /(k€)$/.test(raw)) mult = 1000;
        if(/(\d)(m)$/.test(raw) || /(m€)$/.test(raw)) mult = 1000000;
        if(/mil$/.test(raw)) mult = 1000;
        if(/mill(ones)?$/.test(raw) || /millon(es)?$/.test(raw)) mult = 1000000;
    }

    s = s.replace(/\s/g,'').replace(/€/g,'').replace(/"/g,'');
    // remove textual suffixes
    s = s.replace(/mil/ig,'').replace(/millones/ig,'').replace(/millon(es)?/ig,'');
    s = s.replace(/[kKmM]$/,'');
    // Spanish/Euro formats:
    //  - 1.234.567,89  -> 1234567.89
    //  - 334.000       -> 334000
    //  - 334,00        -> 334.00
    if(s.includes('.') && s.includes(',')){
        // '.' thousands, ',' decimal
        s = s.replace(/\./g,'').replace(',','.');
    }else if(s.includes(',')){
        // ',' decimal
        s = s.replace(',','.');
    }else if(s.includes('.')){
        // If we only have dots, in this dataset it's almost always thousands separators.
        // Treat 334.000, 1.234.567 as thousands.
        const looksLikeThousands = /\.(\d{3})(\.|$)/.test(s);
        if(looksLikeThousands) s = s.replace(/\./g,'');
    }
    const n = parseFloat(s);
    return isNaN(n) ? 0 : (n * mult);
}

function parseDateAny(v){
    if(!v) return null;
    if(v instanceof Date && !isNaN(v)) return v;
    // Excel serial
    if(typeof v === 'number' && v > 25000){
        // Excel date serial (rough)
        const epoch = new Date(Date.UTC(1899, 11, 30));
        return new Date(epoch.getTime() + v*86400000);
    }
    const s = String(v).trim();
    // dd/mm/yyyy or dd-mm-yyyy
    const m = s.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
    if(m){
        const d = parseInt(m[1],10);
        const mo = parseInt(m[2],10)-1;
        let y = parseInt(m[3],10);
        if(y < 100) y += 2000;
        const dt = new Date(y, mo, d);
        return isNaN(dt) ? null : dt;
    }
    const dt = new Date(s);
    return isNaN(dt) ? null : dt;
}

function pickKey(obj, rxList){
    const keys = Object.keys(obj || {});
    for(const rx of rxList){
        const k = keys.find(kk => rx.test(String(kk)));
        if(k) return k;
    }
    return null;
}

function serieToBucket(serieRaw){
    const s = String(serieRaw || '').trim().toUpperCase();
    if(s === 'EA') return 'EXPORT';
    if(s === 'FV' || s === 'FN') return 'NACIONAL';
    if(s.startsWith('CA') || s.includes('CAR')) return 'CARAMELOS';
    return 'HOTELES';
}

function normalizeOrders(rows, year){
    const out = {
        year: String(year || '').trim(),
        rows: [],
        total: 0,
        count: 0,
        monthly: new Array(12).fill(0),
        monthlyCount: new Array(12).fill(0),
        byBucket: { NACIONAL:0, EXPORT:0, HOTELES:0, CARAMELOS:0 },
        clients: {}
    };
    if(!Array.isArray(rows) || !rows.length) return out;

    // Importante: en algunos XLSX la cabecera no está completa en la primera fila (o viene con espacios).
    // Por eso detectamos columnas usando la unión de claves de las primeras filas.
    const unionKeys = Array.from(new Set(
        rows.slice(0, 60).flatMap(r => Object.keys(r || {})).filter(Boolean)
    ));
    const keyProbe = {}; unionKeys.forEach(k => keyProbe[k] = 1);

    // columnas confirmadas por ti (con fallback)
    const kAmount = pickKey(keyProbe, [/^totaliva$/i, /total\s*iva/i, /importe/i, /total/i]);
    const kSerie  = pickKey(keyProbe, [/^serie$/i, /serie/i]);
    const kEstado = pickKey(keyProbe, [/estadodescrip/i, /^estado$/i, /situaci/i]);
    const kFecha  = pickKey(keyProbe, [/fechasalida/i, /fecha\s*salida/i, /fecha/i]);
    const kCliente= pickKey(keyProbe, [/^cliente$/i, /cliente/i]);
    // La descripción real suele estar en "Observaciones" (según tus pedidos ERP).
    // Priorizamos Observaciones por encima de otras columnas tipo Descripción.
    const kDesc   = pickKey(keyProbe, [/observaci/i, /observaci[oó]n/i, /descrip/i, /art[ií]cul/i, /pedido/i]);

    rows.forEach(r => {
        const estado = String(r[kEstado] ?? '').toUpperCase();
        if(!estado.includes('COMPLET')) return;
        const amount = parseEuroNumber(r[kAmount]);
        if(!(amount > 0)) return;
        const serie = r[kSerie];
        const bucket = serieToBucket(serie);

        const dt = parseDateAny(r[kFecha]);
        const mi = dt ? dt.getMonth() : null;

        out.total += amount;
        out.count += 1;
        out.byBucket[bucket] = (out.byBucket[bucket]||0) + amount;
        if(mi !== null){
            out.monthly[mi] += amount;
            out.monthlyCount[mi] += 1;
        }
        const cliente = String(r[kCliente] ?? 'Sin cliente').trim() || 'Sin cliente';
        out.clients[cliente] = (out.clients[cliente]||0) + amount;
        // OJO: Observaciones suele venir cargadísimo (comas, saltos, etc). Lo exportaremos tal cual.
        let desc = String(kDesc ? (r[kDesc] ?? '') : '').trim();
        // Fallback robusto: si la cabecera viene con espacios/BOM o variantes
        if(!desc){
            for(const kk of Object.keys(r)){
                if(/observaci/i.test(kk) || /descrip/i.test(kk) || /detalle/i.test(kk)){
                    const vv = String(r[kk] ?? '').trim();
                    if(vv){ desc = vv; break; }
                }
            }
        }
        out.rows.push({ amount, serie: String(serie||''), bucket, cliente, fecha: dt ? dt.toISOString() : '', desc });
    });
    return out;
}

// Normaliza OFERTAS para Analítica (mismo formato que pedidos, sin filtro COMPLETADO)
function normalizeOffers(rows, year){
    const out = {
        year: String(year || '').trim(),
        rows: [],
        total: 0,
        count: 0,
        monthly: new Array(12).fill(0),
        monthlyCount: new Array(12).fill(0),
        byBucket: { NACIONAL:0, EXPORT:0, HOTELES:0, CARAMELOS:0 },
        clients: {}
    };
    if(!Array.isArray(rows) || !rows.length) return out;

    const unionKeys = Array.from(new Set(
        rows.slice(0, 60).flatMap(r => Object.keys(r || {})).filter(Boolean)
    ));
    const keyProbe = {}; unionKeys.forEach(k => keyProbe[k] = 1);

    // Ofertas típicas: Importe/Total, Fecha, Cliente, Serie/Sección, Observaciones/Descripción
    const kAmount = pickKey(keyProbe, [/importe/i, /total/i, /neto/i, /base/i, /subtotal/i]);
    const kSerie  = pickKey(keyProbe, [/^serie$/i, /serie/i, /secci/i, /area/i]);
    const kFecha  = pickKey(keyProbe, [/fecha/i, /creaci/i, /date/i]);
    const kCliente= pickKey(keyProbe, [/^cliente$/i, /cliente/i, /nombre/i]);
    const kDesc   = pickKey(keyProbe, [/observaci/i, /descrip/i, /detalle/i, /concepto/i]);

    rows.forEach(r => {
        const amount = parseEuroNumber(r[kAmount]);
        if(!(amount > 0)) return;
        const serie = r[kSerie];
        const bucket = serieToBucket(serie);
        const dt = parseDateAny(r[kFecha]);
        const mi = dt ? dt.getMonth() : null;

        out.total += amount;
        out.count += 1;
        out.byBucket[bucket] = (out.byBucket[bucket]||0) + amount;
        if(mi !== null){
            out.monthly[mi] += amount;
            out.monthlyCount[mi] += 1;
        }
        const cliente = String(r[kCliente] ?? 'Sin cliente').trim() || 'Sin cliente';
        out.clients[cliente] = (out.clients[cliente]||0) + amount;
        let desc = String(kDesc ? (r[kDesc] ?? '') : '').trim();
        if(!desc){
            for(const kk of Object.keys(r)){
                if(/observaci/i.test(kk) || /descrip/i.test(kk) || /detalle/i.test(kk)){
                    const vv = String(r[kk] ?? '').trim();
                    if(vv){ desc = vv; break; }
                }
            }
        }
        out.rows.push({ amount, serie: String(serie||''), bucket, cliente, fecha: dt ? dt.toISOString() : '', desc });
    });
    return out;
}

function renderAnalytics(){
    const status = document.getElementById('an2-status');
    const kpiWrap = document.getElementById('an2-kpis');
    const mode = (STATE.analytics && STATE.analytics.mode) ? STATE.analytics.mode : 'orders';
    const byYear = (mode==='offers')
        ? (STATE.analytics && STATE.analytics.offersByYear ? STATE.analytics.offersByYear : {})
        : (STATE.analytics && STATE.analytics.ordersByYear ? STATE.analytics.ordersByYear : {});
    const years = Object.keys(byYear).filter(Boolean).sort();

    if(status){
        if(!years.length){
            status.textContent = mode==='offers'
                ? 'Sin datos. Sube ofertas por año (xlsx/csv) → se comparan automáticamente.'
                : 'Sin datos. Sube pedidos por año (xlsx/csv) → se comparan automáticamente.';
        } else {
            status.textContent = mode==='offers'
                ? `Años cargados: ${years.join(', ')} · Datos: Ofertas (importe>0)`
                : `Años cargados: ${years.join(', ')} · Filtro: Estado=COMPLETADO · totalIVA>0`;
        }
    }

    // KPIs por año
    if(kpiWrap){
        kpiWrap.innerHTML = years.map(y => {
            const d = byYear[y];
            const money = formatMoney(d.total || 0);
            const cnt = (d.count || 0).toLocaleString('es-ES');
            // % vs LY
            const idx = years.indexOf(y);
            let pill = '';
            if(idx > 0){
                const prev = byYear[years[idx-1]];
                const base = prev && prev.total ? prev.total : 0;
                const pct = base ? ((d.total - base)/base)*100 : null;
                if(pct !== null){
                    const sign = pct >= 0 ? '+' : '';
                    pill = `<span class="an2-pill">${sign}${pct.toFixed(1)}% vs LY</span>`;
                }
            }
            const sub = mode==='offers' ? `${cnt} ofertas` : `${cnt} pedidos completados`;
            return `
                <div class="an2-kpi">
                    <div class="an2-kpi-head">
                        <div class="an2-kpi-year">${y}</div>
                        ${pill}
                    </div>
                    <div class="an2-kpi-val">${money}</div>
                    <div class="an2-kpi-sub">${sub}</div>
                </div>
            `;
        }).join('');
    }

    // charts
    renderAnalyticsMonthly(years, byYear);
    renderAnalyticsYearly(years, byYear);
    renderAnalyticsSeries(years, byYear);
    renderAnalyticsTopClients(years, byYear);
}

function yearColor(y){
    const yy = String(y);
    if(yy === '2024') return '#3b82f6';
    if(yy === '2025') return '#22c55e';
    if(yy === '2026') return '#f97316';
    // fallback
    return '#6366f1';
}

function withAlpha(hex, a){
    // hex #RRGGBB
    const h = hex.replace('#','');
    const r = parseInt(h.substring(0,2),16);
    const g = parseInt(h.substring(2,4),16);
    const b = parseInt(h.substring(4,6),16);
    return `rgba(${r},${g},${b},${a})`;
}

function destroyChart(id){
    if(charts[id] && charts[id].destroy) charts[id].destroy();
    charts[id] = null;
}

function renderAnalyticsMonthly(years, byYear){
    const el = document.getElementById('an2-monthly');
    if(!el) return;
    destroyChart('an2-monthly');
    const labels = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
    const datasets = years.map(y => {
        const c = yearColor(y);
        const d = byYear[y] || {};
        return {
            label: y,
            data: (d.monthly || new Array(12).fill(0)),
            borderColor: c,
            backgroundColor: withAlpha(c, 0.20),
            fill: true,
            tension: 0.35,
            pointRadius: 2,
        };
    });
    charts['an2-monthly'] = safeChart(el, {
        type: 'line',
        data: { labels, datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'top' } },
            scales: {
                y: { ticks: { callback: v => Number(v).toLocaleString('es-ES') } }
            }
        }
    });
}

function renderAnalyticsYearly(years, byYear){
    const el = document.getElementById('an2-yearly');
    if(!el) return;
    destroyChart('an2-yearly');
    const amounts = years.map(y => (byYear[y]?.total || 0));
    const counts = years.map(y => (byYear[y]?.count || 0));
    const colors = years.map(y => withAlpha(yearColor(y), 0.75));
    charts['an2-yearly'] = safeChart(el, {
        data: {
            labels: years,
            datasets: [
                { type:'bar', label:'Importe (totalIVA)', data: amounts, backgroundColor: colors, yAxisID:'y' },
                { type:'line', label:'Nº pedidos', data: counts, borderColor:'#111827', backgroundColor:'#111827', yAxisID:'y1', tension:0.25, pointRadius:2 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'top' } },
            scales: {
                y: { position:'left', ticks: { callback: v => Number(v).toLocaleString('es-ES') } },
                y1: { position:'right', grid: { drawOnChartArea: false } }
            }
        }
    });
}

function renderAnalyticsSeries(years, byYear){
    const el = document.getElementById('an2-series');
    if(!el) return;
    destroyChart('an2-series');
    const labels = ['NACIONAL','EXPORT','HOTELES','CARAMELOS'];
    const datasets = years.map(y => {
        const c = yearColor(y);
        const byB = byYear[y]?.byBucket || {};
        return {
            label: y,
            data: labels.map(l => byB[l] || 0),
            backgroundColor: withAlpha(c, 0.80)
        };
    });
    charts['an2-series'] = safeChart(el, {
        type: 'bar',
        data: { labels, datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position:'top' } },
            scales: {
                y: { ticks: { callback: v => Number(v).toLocaleString('es-ES') } }
            }
        }
    });
}

function renderAnalyticsTopClients(years, byYear){
    const el = document.getElementById('an2-top');
    if(!el) return;
    destroyChart('an2-top');

    // top 10 global (sum across years)
    const global = {};
    years.forEach(y => {
        const c = byYear[y]?.clients || {};
        Object.entries(c).forEach(([k,v]) => global[k] = (global[k]||0) + v);
    });
    const topClients = Object.entries(global)
        .sort((a,b)=>b[1]-a[1])
        .slice(0,10)
        .map(e=>e[0]);

    const datasets = years.map(y => {
        const c = yearColor(y);
        const m = byYear[y]?.clients || {};
        return {
            label: y,
            data: topClients.map(cl => m[cl] || 0),
            backgroundColor: withAlpha(c, 0.80)
        };
    });
    charts['an2-top'] = safeChart(el, {
        type: 'bar',
        data: { labels: topClients, datasets },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position:'top' } },
            scales: {
                x: { ticks: { callback: v => Number(v).toLocaleString('es-ES') } }
            }
        }
    });
}

function renderTable(view) {
    const t = view.includes('rfq') ? 'rfqs' : (view.includes('offer') ? 'offers' : 'orders');
    const mapTitle = {rfqs:'Lista RFQs', offers:'Lista Ofertas', orders:'Lista Pedidos'};
    document.getElementById('table-title').innerText = mapTitle[t] || t.toUpperCase();
    document.getElementById('thead').innerHTML = '<th>Cliente</th><th>Fecha</th><th>Importe</th><th>Estado</th><th>Agente</th>';
    const q = (window.__CCH_SEARCH_Q||'').toLowerCase().trim();
    const rows = q ? STATE[t].filter(x => (x.client||'').toLowerCase().includes(q) || (x.desc||'').toLowerCase().includes(q) || String(x.id||'').includes(q)) : STATE[t];
    document.getElementById('tbody').innerHTML = rows.map(i => `<tr><td>${i.client}</td><td>${i.date}</td><td>${formatMoney(i.amount)}</td><td>${i.status}</td><td>${i.agent}</td></tr>`).join('');
}

// --- MODAL DETALLE EN ESPAÑOL v55 ---
window.openDetail = (t, i) => {
    const item = STATE[t][i];
    document.getElementById('modal-body').innerHTML = `
        <div class="detail-row"><span class="detail-label">CLIENTE</span><span>${item.client}</span></div>
        <div class="detail-row"><span class="detail-label">IMPORTE</span><span style="font-weight:900">${formatMoney(item.amount)}</span></div>
        <div class="detail-row"><span class="detail-label">FECHA</span><span>${item.date}</span></div>
        <div class="detail-row"><span class="detail-label">AGENTE</span><span>${item.agent}</span></div>
        <div class="detail-row"><span class="detail-label">ESTADO</span><span class="status-pill">${item.status}</span></div>
        <div style="margin-top:15px"><span class="detail-label">ASUNTO / NOTAS</span><textarea style="width:100%;height:80px;border:1px solid #ccc;padding:5px;margin-top:5px">${item.desc}</textarea></div>
    `;
    document.getElementById('modal-overlay').classList.remove('hidden');
};
window.closeModal = () => document.getElementById('modal-overlay').classList.add('hidden');
function formatMoney(n) { return new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(n); }
function initMocks() { if(!STATE.rfqs.length) STATE.rfqs = [{client:'Test RFQ', amount:0, date:'09/02/2026', status:'Nuevo', agent:'Alejandro', desc:'Simulación'}]; }
function fullReset() { if(confirm("¿Borrar?")) { localStorage.clear(); location.reload(); } }

function renderMiniCharts() { 
    ['nac','exp','hot','car'].forEach(k => { 
        const ctx = document.getElementById(`c-mini-${k}`);
        if(ctx) {
            // Mini barras: Objetivo (azul claro) vs Real (rosa suave) por cuatrimestre
            const data = (STATE.objectives && STATE.objectives.data && STATE.objectives.data[k]) ? STATE.objectives.data[k] : null;
            const obj = (data && data.objCuatr) ? data.objCuatr : {c1:0,c2:0,c3:0};
            const real = (data && data.realCuatr) ? data.realCuatr : ((STATE.objectives.breakdown && STATE.objectives.breakdown[k]) ? STATE.objectives.breakdown[k] : {c1:0,c2:0,c3:0});
            if(charts[k]) charts[k].destroy();
            charts[k] = safeChart(ctx, {
                type:'bar', 
                data:{
                    labels:['C1 (Ene-Abr)', 'C2 (May-Ago)', 'C3 (Sep-Dic)'], 
                    datasets:[
                        { label:'Objetivo', data:[obj.c1, obj.c2, obj.c3], backgroundColor:'#93c5fd' },
                        { label:'Real', data:[real.c1, real.c2, real.c3], backgroundColor:'#fda4af' }
                    ]
                }, 
                options:{
                    plugins:{legend:false, tooltip:{enabled:true}},
                    scales:{x:{display:false}, y:{display:false}},
                    maintainAspectRatio:false
                }
            });
        }
    }); 
}

// v56 · Gráficas Objetivos (solo Nacional)
function renderObjectiveCharts(){
    try{
        const monthsLbl = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];

        const getSeries = (key) => {
            const data = (STATE.objectives && STATE.objectives.data && STATE.objectives.data[key]) ? STATE.objectives.data[key] : null;

            const realMonthly = data && data.realMonthly ? data.realMonthly : ((STATE.objectives.monthly && STATE.objectives.monthly[key]) ? STATE.objectives.monthly[key] : new Array(12).fill(0));
            const objMonthly  = data && data.objMonthly  ? data.objMonthly  : new Array(12).fill(0);

            const realCuatr = data && data.realCuatr ? data.realCuatr : ((STATE.objectives.breakdown && STATE.objectives.breakdown[key]) ? STATE.objectives.breakdown[key] : {c1:0,c2:0,c3:0});
            const objCuatr  = data && data.objCuatr  ? data.objCuatr  : {c1:0,c2:0,c3:0};

            return { realMonthly, objMonthly, realCuatr, objCuatr };
        };

        const renderPair = (key, mesId, cuatrId, chartKeyMes, chartKeyCuatr) => {
            const mesCanvas = document.getElementById(mesId);
            const cuatrCanvas = document.getElementById(cuatrId);
            if(!mesCanvas || !cuatrCanvas) return;

            const s = getSeries(key);

            charts[chartKeyMes] && charts[chartKeyMes].destroy && charts[chartKeyMes].destroy();
            charts[chartKeyCuatr] && charts[chartKeyCuatr].destroy && charts[chartKeyCuatr].destroy();

            charts[chartKeyMes] = safeChart(mesCanvas, {
                type: 'bar',
                data: {
                    labels: monthsLbl,
                    datasets: [
                        { label: 'Objetivo (€)', data: s.objMonthly },
                        { label: 'Real (€)', data: s.realMonthly }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: true } },
                    scales: { y: { ticks: { callback: (v) => Number(v).toLocaleString('es-ES') } } }
                }
            });

            charts[chartKeyCuatr] = safeChart(cuatrCanvas, {
                type: 'bar',
                data: {
                    labels: ['1º Cuatr.','2º Cuatr.','3º Cuatr.'],
                    datasets: [
                        { label: 'Objetivo (€)', data: [s.objCuatr.c1||0, s.objCuatr.c2||0, s.objCuatr.c3||0] },
                        { label: 'Real (€)', data: [s.realCuatr.c1||0, s.realCuatr.c2||0, s.realCuatr.c3||0] }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: true } },
                    scales: { y: { ticks: { callback: (v) => Number(v).toLocaleString('es-ES') } } }
                }
            });
        };

        renderPair('nac','c-nac-mes','c-nac-cuatr','objNacMes','objNacCuatr');
        renderPair('exp','c-exp-mes','c-exp-cuatr','objExpMes','objExpCuatr');
        renderPair('hot','c-hot-mes','c-hot-cuatr','objHotMes','objHotCuatr');
        renderPair('car','c-car-mes','c-car-cuatr','objCarMes','objCarCuatr');
    }catch(err){
        console.warn('renderObjectiveCharts error', err);
    }
}

// v65 · Panel Estratégico (Objetivos): resumen 4 series + global
function updateStrategicPanel(){
    const d = (STATE.objectives && STATE.objectives.data) ? STATE.objectives.data : {};
    const series = ['nac','exp','hot','car'];
    let objG = 0, realG = 0;

    const mapId = {nac:'sp-obj-nac', exp:'sp-obj-exp', hot:'sp-obj-hot', car:'sp-obj-car'};
    series.forEach(k=>{
        const item = d[k] || {};
        const obj = Number(item.objTotal||0);
        const real = Number(item.realTotal||0);
        objG += obj; realG += real;
        const el = document.getElementById(mapId[k]);
        if(el) el.textContent = formatMoney(obj);
    });

    const gap = realG - objG;
    const elObj = document.getElementById('sp-obj-global');
    const elReal = document.getElementById('sp-real-global');
    const elGap = document.getElementById('sp-gap-global');
    if(elObj) elObj.textContent = formatMoney(objG);
    if(elReal) elReal.textContent = formatMoney(realG);
    if(elGap){
        elGap.textContent = formatMoney(gap);
        elGap.classList.toggle('text-danger', gap < 0);
    }
}


function initGlobalSearchAndMic(){
    // Buscador: soporta distintos IDs típicos
    const input = document.getElementById('buscador') || document.getElementById('search') || document.getElementById('global-search') || document.getElementById('search-input') || document.getElementById('q');
    if(input && !input.__cchBound){
        input.__cchBound = true;
        input.addEventListener('input', () => {
            const q = String(input.value||'').toLowerCase().trim();
            window.__CCH_SEARCH_Q = q;
            updateUI();
            const view = location.hash.replace('#','') || '';
            if(view.includes('rfq')||view.includes('offer')||view.includes('order')) renderTable(view);
        });
    }

    // Micrófono (si existe). Nunca debe romper la app si el navegador no lo soporta.
    const micBtn = document.getElementById('mic-btn') || document.getElementById('mic') || document.querySelector('.mic-btn') || document.querySelector('.mic-icon') || document.querySelector('[data-mic]');
    if(micBtn && !micBtn.__cchBound){
        micBtn.__cchBound = true;
        micBtn.addEventListener('click', async () => {
                const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if(!SpeechRecognition){ alert('Micrófono no disponible en este navegador.'); return; }
            try{
                const rec = new SpeechRecognition();
                rec.lang = 'es-ES';
                rec.interimResults = false;
                rec.maxAlternatives = 1;
                rec.onresult = (ev) => {
                    const text = ev.results && ev.results[0] && ev.results[0][0] ? ev.results[0][0].transcript : '';
                    if(input){ input.value = text; input.dispatchEvent(new Event('input')); }
                };
                rec.onerror = () => {};
                rec.start();
            }catch(err){
                alert('No se pudo iniciar el micrófono (permiso o compatibilidad).');
            }
        });
    }
}


function escapeHtml(str){ return String(str||'').replace(/[&<>"']/g, s=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[s])); }
function escapeAttr(str){ return escapeHtml(str).replace(/`/g,'&#96;'); }
