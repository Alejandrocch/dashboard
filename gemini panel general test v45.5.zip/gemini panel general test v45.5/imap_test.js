const fs = require("fs");
const path = require("path");
const { ImapFlow } = require("imapflow");
require("dotenv").config();

function safeName(s) {
  return String(s || "")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
    .slice(0, 180);
}
function classifyEmail({ subject = "", from = "", text = "", attachmentNames = [] }) {
  const s = (subject || "").toLowerCase();
  const b = (text || "").toLowerCase();
  const a = attachmentNames.map(x => (x || "").toLowerCase()).join(" ");

  const hay = `${s}\n${b}\n${a}`;

  const rfqWords = [
    "rfq", "solicitud", "consulta", "precio", "precios", "presupuesto", "cotizacion", "cotización",
    "tarifa", "referencia", "referencias", "articulo", "artículos", "sku", "modelo",
    "necesito", "podéis", "puedes", "podrian", "podrían", "me pasas", "me podéis"
  ];

  const ofertaWords = [
    "oferta", "quotation", "quote", "cotización enviada", "envío de oferta",
    "revisión", "visado", "valida", "validación", "aceptación", "aceptada", "rechazada",
    "seguimiento oferta", "recordatorio oferta"
  ];

  const pedidoWords = [
    "pedido", "order", "po", "purchase order", "confirmación", "confirmacion",
    "adjunto pedido", "número de pedido", "numero de pedido", "entrega", "albarán", "factura"
  ];

  const has = (arr) => arr.some(w => hay.includes(w));

  if (has(pedidoWords)) return "PEDIDO";
  if (has(ofertaWords)) return "OFERTA";
  if (has(rfqWords)) return "RFQ";
  return "OTROS";
}

(async () => {
  const client = new ImapFlow({
    host: process.env.IMAP_HOST,
    port: Number(process.env.IMAP_PORT || 993),
    secure: String(process.env.IMAP_TLS).toLowerCase() === "true",
    auth: { user: process.env.IMAP_USER, pass: process.env.IMAP_PASS },
    logger: false
  });

  await client.connect();
  console.log("✅ Connected");

  const mailbox = process.env.IMAP_MAILBOX || "INBOX";
  const lock = await client.getMailboxLock(mailbox);

  try {
    console.log(`✅ Mailbox: ${client.mailbox.path} (messages: ${client.mailbox.exists})`);

    const saveDir = process.env.IMAP_SAVE_DIR || "./imap_downloads";
    if (!fs.existsSync(saveDir)) fs.mkdirSync(saveDir, { recursive: true });
    const inbox = [];


    const sinceDays = Number(process.env.IMAP_SINCE_DAYS || 14);
    const since = new Date(Date.now() - sinceDays * 24 * 60 * 60 * 1000);

    // Busca NO LEÍDOS desde "since"
    const uids = await client.search({ seen: false, since });
    console.log(`🔎 UNSEEN since ${since.toISOString().slice(0, 10)}: ${uids.length}`);

    // Si no hay unseen, coge últimos 10 como fallback (para test)
    // --- TARGET UID LIST (robusto) ---
let targetUids = [];

const mode = (process.env.IMAP_MODE || "UNSEEN").toUpperCase();

if (mode === "UNSEEN") {
  // UNSEEN desde fecha
  targetUids = await client.search({ seen: false, since });
  console.log(`🔎 UNSEEN since ${since.toISOString().slice(0, 10)}: ${targetUids.length}`);
}

if (!targetUids.length) {
  // Fallback seguro: coge TODOS los UIDs y quédate con los últimos N
  const allUids = await client.search({ all: true });
  const n = Math.min(Number(process.env.IMAP_LAST_N || 10), allUids.length);
  targetUids = allUids.slice(-n);
  console.log(`ℹ️ Fallback LAST: scanning last ${targetUids.length} messages (by UID).`);
}


    let saved = 0;

    for (const uid of targetUids) {
      const msg = await client.fetchOne(uid, { envelope: true, bodyStructure: true, uid: true });
      const subject = msg.envelope?.subject || "";
      const dateIso = msg.envelope?.date ? new Date(msg.envelope.date).toISOString().slice(0, 10) : "nodate";
      const messageId = safeName(msg.envelope?.messageId || `uid-${uid}`);

      const attachments = [];
      const attachmentNames = attachments
  .map(a => a.dispositionParameters?.filename || "")
  .filter(Boolean);

const category = classifyEmail({
  subject,
  attachmentNames
});

inbox.push({
  id: msg.envelope?.messageId || `uid-${uid}`,
  uid,
  date: msg.envelope?.date ? new Date(msg.envelope.date).toISOString() : null,
  from: msg.envelope?.from?.[0]?.address || "",
  subject,
  category,
  hasAttachments: attachments.length > 0,
  attachments: attachmentNames
});

      const walk = (node) => {
        if (!node) return;
        if (Array.isArray(node)) return node.forEach(walk);
        if (node.disposition === "attachment" && node.part) attachments.push(node);
        if (node.childNodes) walk(node.childNodes);
      };
      walk(msg.bodyStructure);

      if (!attachments.length) continue;

      console.log(`\n📩 UID ${uid} | ${dateIso} | ${subject} | attachments=${attachments.length}`);

      for (const att of attachments) {
        const filename = att.dispositionParameters?.filename || `attachment-${att.part}`;
        

        // Solo CSV (de momento)
        const lower = filename.toLowerCase();

// MODO TEST: guardar TODO
// (luego volveremos a filtrar por CSV)


        const { content } = await client.download(uid, att.part);
        const outName = `${dateIso}__${messageId}__${safeName(filename)}`;
        const outPath = path.join(saveDir, outName);

        await new Promise((resolve, reject) => {
          const ws = fs.createWriteStream(outPath);
          content.pipe(ws);
          content.on("error", reject);
          ws.on("finish", resolve);
          ws.on("error", reject);
        });

        saved++;
        console.log(`✅ Saved attachment: ${outPath}`);

      }
    }

    console.log(`\n🎯 Done. CSV saved: ${saved}`);

fs.writeFileSync("emails_inbox.json", JSON.stringify(inbox, null, 2), "utf8");
  console.log(`✅ Wrote emails_inbox.json (${inbox.length} items)`);
  
} finally {
    lock.release();
    await client.logout();
    
    console.log("✅ Logged out");
  }
})().catch((e) => {
  console.error("❌ IMAP attachment fetch failed (full):");
  console.error(e);
  process.exit(1);
});

