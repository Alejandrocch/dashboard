C&CH DASHBOARDS — v45.4
Fecha del paquete: 17/12/2025

Incluye:
- index.html
- styles.css
- app.js
- README_v45.txt
- CCH_v45_codigo_comentado.pdf

Notas (v45.4):
- Parser CSV robusto (campos multilínea entrecomillados, comillas escapadas, \r\n / \n, detección de separador ;/,).
- Mapeo requerido:
  - Pedidos: "Pedido (ID)", Serie, "NúmeroPedido", Estado, TotalIVA
  - Ofertas: Serie, NumOferta, EstadoDescrip, Visado, TotalIVA
- Filtros globales (modelo B): Estado Ofertas / Visado / Estado Pedidos (afectan dashboard y vistas detalle).
- v45.4: Orden por defecto SIEMPRE por fecha más reciente (RFQs / Ofertas / Pedidos) + toggle (▼/▲) para invertir a más antiguas.
- v45.4: Filtros globales aplican también a RFQs (serie / fecha / búsqueda) y se auto-aplican.
- Botón "Quitar filtros" para volver al dashboard general sin filtros.
- Layout ancho sin zonas muertas (wrap ~1900–1960px).
- Tipografía mayor y separación real entre líneas:
  - Listas: gap 10px
  - Tablas: border-spacing 0 10px
- Modal popup: clic en item/fila abre el detalle completo (observaciones incluidas).
- Panel central 3 columnas (RFQs / Ofertas / Pedidos) + pestañas detalle.

Siguiente paso (tras tu OK): integrar emails IMAP en vivo para RFQs.
