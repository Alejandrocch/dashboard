/* app.js — C&CH DASHBOARDS v50 (master)
   - Carga Ofertas/Pedidos desde CSV (mapeo tolerante)
   - Filtros globales (serie, comercial, fecha, texto)
   - Panel central 3 columnas + paneles detalle por pestaña
   - Modal popup de detalle para leer observaciones completas
   - Theme Dark/Light (persistente en localStorage)
*/
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

// --- Theme toggle (Dark/Light) ---
function applyTheme(theme){
  const t = (theme === 'light') ? 'light' : 'dark';
  document.body.setAttribute('data-theme', t);
  // En la UI v50 el botón se llama "btnTheme" y muestra "Tema: Dark/Light".
  const btn = document.getElementById('btnTheme') || document.getElementById('themeToggle');
  const label = document.getElementById('themeLabel');
  if(label){
    label.textContent = (t === 'light') ? 'Light' : 'Dark';
  }
  if(btn){
    // Si no hay <span id="themeLabel">, dejamos un fallback simple
    if(!label){
      btn.textContent = (t === 'light') ? 'Tema: Light' : 'Tema: Dark';
    }
    btn.setAttribute('aria-label', `Cambiar a tema ${t === 'light' ? 'oscuro' : 'claro'}`);
  }
  try{ localStorage.setItem('cch_theme', t); }catch{}
}
function initTheme(){
  let saved = 'dark';
  try{ saved = localStorage.getItem('cch_theme') || 'dark'; }catch{}
  applyTheme(saved);
  const btn = document.getElementById('btnTheme') || document.getElementById('themeToggle');
  if(btn){
    btn.addEventListener('click', ()=>{
      const cur = document.body.getAttribute('data-theme') || 'dark';
      applyTheme(cur === 'dark' ? 'light' : 'dark');
    });
  }
}

const state = { ofertasRaw:[], pedidosRaw:[], rfqs:[], filters:{serie:'', comercial:'', desde:'', hasta:'', q:''} };

function norm(s){ return String(s??'').trim(); }
function keyify(s){ return norm(s).toLowerCase().replace(/\s+/g,''); }
function toNumber(v){
  if(v==null) return 0;
  const s = String(v).trim();
  if(!s) return 0;
  const cleaned = s.replace(/\./g,'').replace(',', '.').replace(/[^0-9.-]/g,'');
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}
function fmtEUR(n){
  try{ return new Intl.NumberFormat('es-ES',{style:'currency',currency:'EUR'}).format(n||0); }
  catch{ return (n||0).toFixed(2)+' €'; }
}
function fmtDate(d){
  if(!d) return '';
  const s = String(d).trim();
  if(/\d{2}\/\d{2}\/\d{4}/.test(s)) return s;
  const dt = new Date(s);
  if(!isNaN(dt.getTime())) return dt.toLocaleString('es-ES');
  return s;
}
function parseDateToISO(s){
  if(!s) return '';
  const t = String(s).trim();
  const m = t.match(/(\d{2})\/(\d{2})\/(\d{4})/);
  if(m) return `${m[3]}-${m[2]}-${m[1]}`;
  const dt = new Date(t);
  if(!isNaN(dt.getTime())) return dt.toISOString().slice(0,10);
  return '';
}
function escapeHtml(s){
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function short(s, n=64){ const t=norm(s); return t.length>n ? t.slice(0,n-1)+'…' : t; }
function sum(arr, fn){ return arr.reduce((a,x)=>a+(fn(x)||0), 0); }
function countWhere(arr, pred){ return arr.reduce((a,x)=>a+(pred(x)?1:0), 0); }

const mapOfertas = {
  serie:['serie'],
  numOferta:['numoferta','nºoferta','nooferta','numerooferta','oferta'],
  fecha:['fecha','fechaemision','fechaemisión'],
  idCliente:['idcliente','codcliente','clienteid'],
  cliente:['cliente'],
  razon:['razonsocial','razónsocial','razonsoc'],
  comercial:['comercial','agente','vendedor'],
  estado:['estadodescrp','estadodescrip','estado','estadodescripcion'],
  visado:['visado'],
  obs:['observaciones','observacion','obs'],
  totalIva:['totaliva','importe','importeiva','total'],
  idOferta:['idoferta','id oferta','id_oferta']
};
const mapPedidos = {
  idPedido:['idpedido','id pedido','id_pedido'],
  serie:['serie'],
  numPedido:['numeropedido','númeropedido','nºpedido','nopedido','pedido','numeropedido'],
  fecha:['fecha','fechapedido','fecha pedido'],
  cliente:['cliente'],
  idCliente:['idcliente','codcliente','clienteid'],
  razon:['razonsocial','razónsocial'],
  desc:['descripcionpedido','descripciónpedido','descripcion','descripción'],
  estado:['estado'],
  totalIva:['totaliva','importe','total'],
  obs:['observaciones','observacion','obs']
};
function pickCol(headerMap, cols){
  const colKeys = cols.map(c=>keyify(c));
  const out = {};
  for(const [field, aliases] of Object.entries(headerMap)){
    let idx = -1;
    for(const a of aliases){
      idx = colKeys.indexOf(keyify(a));
      if(idx>=0) break;
    }
    out[field]=idx;
  }
  return out;
}

function parseCSV(text){
  const lines = text.replace(/\r/g,'').split('\n').filter(l=>l.trim().length);
  if(!lines.length) return {cols:[], rows:[]};
  const sep = (lines[0].includes(';') && !lines[0].includes(',')) ? ';' : ',';
  const cols = split(lines[0], sep);
  const rows = [];
  for(let i=1;i<lines.length;i++) rows.push(split(lines[i], sep));
  return {cols, rows};

  function split(line, sep){
    const res=[]; let cur=''; let inQ=false;
    for(let i=0;i<line.length;i++){
      const ch=line[i];
      if(ch==='"'){
        if(inQ && line[i+1]==='"'){ cur+='"'; i++; }
        else inQ=!inQ;
      }else if(ch===sep && !inQ){
        res.push(cur); cur='';
      }else cur+=ch;
    }
    res.push(cur);
    return res;
  }
}

function badgeFromEstado(estado){
  const e = norm(estado).toLowerCase();
  if(/acept|final|complet/.test(e)) return { text: estado||'OK', kind:'ok' };
  if(/pend|eval|curso|prepar|generad/.test(e)) return { text: estado||'En curso', kind:'warn' };
  if(/rech/.test(e)) return { text: estado||'Rechazada', kind:'bad' };
  return { text: estado||'N/D', kind:'' };
}

function renderKV(obj){
  const wrap=document.createElement('div');
  for(const [k,v] of Object.entries(obj)){
    const row=document.createElement('div');
    row.className='kv';
    row.innerHTML=`<div class="k">${escapeHtml(k)}</div><div class="v">${escapeHtml(v??'')}</div>`;
    wrap.appendChild(row);
  }
  return wrap;
}
function openModal(title, sub, node){
  $('#modalTitle').textContent=title;
  $('#modalSub').textContent=sub||'';
  const body=$('#modalBody'); body.innerHTML=''; body.appendChild(node);
  $('#modal').classList.remove('hidden');
}
function closeModal(){ $('#modal').classList.add('hidden'); }

function topNCount(arr, keyFn, n=5){
  const map=new Map();
  for(const x of arr){ const k=norm(keyFn(x)||'N/D')||'N/D'; map.set(k,(map.get(k)||0)+1); }
  return Array.from(map.entries()).sort((a,b)=>b[1]-a[1]).slice(0,n);
}
function topNSum(arr, keyFn, sumFn, n=5){
  const map=new Map();
  for(const x of arr){ const k=norm(keyFn(x)||'N/D')||'N/D'; map.set(k,(map.get(k)||0)+(sumFn(x)||0)); }
  return Array.from(map.entries()).sort((a,b)=>b[1]-a[1]).slice(0,n);
}

function renderSparks(root, arr, kind){
  const byEstado=topNCount(arr, r=>r.estado, 4);
  const bySerie=topNCount(arr, r=>r.serie, 4);
  const byDay=topNCount(arr, r=>parseDateToISO(r.fecha)||'N/D', 4);

  const box=(title, rows)=>{
    const max = rows[0]?.[1]||1;
    return `<div class="spark"><div class="sparkTitle">${escapeHtml(title)}</div>
      ${rows.map(([k,v])=>`
        <div class="sparkRow">
          <span>${escapeHtml(short(k,18))}</span>
          <span style="display:flex;align-items:center;gap:10px">
            <span>${escapeHtml(String(v))}</span>
            <span class="bar"><i style="width:${Math.min(100,(v/max)*100)}%"></i></span>
          </span>
        </div>`).join('')}
    </div>`;
  };
  root.innerHTML =
    box(kind==='rfq'?'RFQs por estado':(kind==='oferta'?'Ofertas por estado':'Pedidos por estado'), byEstado) +
    box(kind==='rfq'?'RFQs por serie':(kind==='oferta'?'Ofertas por serie':'Pedidos por serie'), bySerie) +
    box(kind==='rfq'?'RFQs últimos días':(kind==='oferta'?'Ofertas por día':'Pedidos por día'), byDay);
}

function renderList(root, items){
  root.innerHTML='';
  for(const it of items){
    const el=document.createElement('div');
    el.className='item';
    el.innerHTML = `
      <div class="itemTop">
        <div>
          <div class="itemTitle">${escapeHtml(it.title)}</div>
          <div class="itemMeta">${escapeHtml(it.meta)}</div>
        </div>
        <div class="badge ${it.badge.kind||''}">${escapeHtml(it.badge.text||'')}</div>
      </div>
      <div class="itemBottom">
        ${it.tags.map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}
        <span class="tag">Ver detalle</span>
      </div>
    `;
    el.addEventListener('click', it.onOpen);
    root.appendChild(el);
  }
}

function filterRows(rows){
  const {serie, comercial, desde, hasta, q} = state.filters;
  const ql = norm(q).toLowerCase();
  return rows.filter(r=>{
    if(serie && norm(r.serie)!==serie) return false;
    if(comercial && norm(r.comercial)!==comercial) return false;

    const iso=parseDateToISO(r.fecha);
    if(desde && iso && iso<desde) return false;
    if(hasta && iso && iso>hasta) return false;

    if(ql){
      const hay=[r.cliente,r.razon,r.numOferta,r.numPedido,r.idPedido,r.estado,r.obs,r.desc,r.comercial]
        .map(x=>norm(x).toLowerCase()).join(' | ');
      if(!hay.includes(ql)) return false;
    }
    return true;
  }).sort((a,b)=>(parseDateToISO(b.fecha)||'').localeCompare(parseDateToISO(a.fecha)||''));
}

function rebuildFilterOptions(){
  const series=new Set(), coms=new Set();
  for(const r of state.ofertasRaw){ if(r.serie) series.add(r.serie); if(r.comercial) coms.add(r.comercial); }
  for(const r of state.pedidosRaw){ if(r.serie) series.add(r.serie); if(r.comercial) coms.add(r.comercial); }

  const serieSel=$('#filterSerie'), comSel=$('#filterComercial');
  const curS=serieSel.value, curC=comSel.value;

  serieSel.innerHTML = '<option value="">Todas</option>' + Array.from(series).sort().map(s=>`<option>${escapeHtml(s)}</option>`).join('');
  comSel.innerHTML  = '<option value="">Todos</option>' + Array.from(coms).sort().map(s=>`<option>${escapeHtml(s)}</option>`).join('');

  serieSel.value=curS||''; comSel.value=curC||'';
}

function renderTables(ofertas, pedidos){
  const tbOf=$('#tblOfertas tbody'); tbOf.innerHTML='';
  for(const r of ofertas.slice(0, 800)){
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td>${escapeHtml(r.serie||'')}</td>
      <td>${escapeHtml(r.numOferta||'')}</td>
      <td>${escapeHtml(fmtDate(r.fecha)||'')}</td>
      <td>${escapeHtml(r.cliente||'')}</td>
      <td>${escapeHtml(r.razon||'')}</td>
      <td>${escapeHtml(r.comercial||'')}</td>
      <td>${escapeHtml(r.estado||'')}</td>
      <td>${escapeHtml(r.visado||'')}</td>
      <td class="right">${escapeHtml(fmtEUR(r.totalIva))}</td>
      <td class="obsCell">${escapeHtml(r.obs||'')}</td>
      <td class="right">${escapeHtml(r.idOferta||'')}</td>
    `;
    tr.addEventListener('click', ()=>openModal('Oferta', `${r.serie||''} · ${r.numOferta||''}`, renderKV({
      'Serie':r.serie,'Nº Oferta':r.numOferta,'Fecha':fmtDate(r.fecha),'Cliente':r.cliente,'Razón social':r.razon,
      'Comercial':r.comercial,'Estado':r.estado,'Visado':r.visado,'Total IVA':fmtEUR(r.totalIva),'Id Oferta':r.idOferta,'Observaciones':r.obs
    })));
    tbOf.appendChild(tr);
  }

  const tbPe=$('#tblPedidos tbody'); tbPe.innerHTML='';
  for(const r of pedidos.slice(0, 800)){
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td class="right">${escapeHtml(r.idPedido||'')}</td>
      <td>${escapeHtml(r.serie||'')}</td>
      <td>${escapeHtml(r.numPedido||'')}</td>
      <td>${escapeHtml(fmtDate(r.fecha)||'')}</td>
      <td>${escapeHtml(r.cliente||'')}</td>
      <td>${escapeHtml(r.razon||'')}</td>
      <td class="descCell">${escapeHtml(r.desc||'')}</td>
      <td>${escapeHtml(r.estado||'')}</td>
      <td class="right">${escapeHtml(fmtEUR(r.totalIva))}</td>
      <td class="obsCell">${escapeHtml(r.obs||'')}</td>
    `;
    tr.addEventListener('click', ()=>openModal('Pedido', `${r.serie||''} · ${r.numPedido||''}`, renderKV({
      'Id Pedido':r.idPedido,'Serie':r.serie,'Nº Pedido':r.numPedido,'Fecha':fmtDate(r.fecha),'Cliente':r.cliente,'Id Cliente':r.idCliente,
      'Razón social':r.razon,'Descripción':r.desc,'Estado':r.estado,'Total IVA':fmtEUR(r.totalIva),'Observaciones':r.obs
    })));
    tbPe.appendChild(tr);
  }
}

function renderRFQs(){
  const por=countWhere(state.rfqs, r=>/por contestar/i.test(r.estado||''));
  const cont=countWhere(state.rfqs, r=>/contestad/i.test(r.estado||''));
  const prop=countWhere(state.rfqs, r=>/propuesta/i.test(r.estado||''));
  $('#rfqK1').textContent=por; $('#rfqK2').textContent=cont; $('#rfqK3').textContent=prop; $('#rfqK4').textContent=state.rfqs.length;

  renderList($('#rfqList'), state.rfqs.slice(0,8).map(r=>({
    title:`${r.empresa} · ${r.id}`,
    meta:`${r.fecha} · ${r.serie} · ${r.email}`,
    badge: badgeFromEstado(r.estado),
    tags:[`Estado: ${r.estado}`, r.tel?`Tel: ${r.tel}`:'Tel: —', `Asunto: ${short(r.asunto,34)}`],
    onOpen: ()=>openModal('RFQ (email)', `${r.empresa} · ${r.id}`, renderKV({
      'Empresa':r.empresa,'Fecha':r.fecha,'Serie':r.serie,'Estado':r.estado,'Email':r.email,'Teléfono':r.tel,'Asunto':r.asunto,'Cuerpo':r.cuerpo
    }))
  })));

  const panel=$('#rfqPanelList');
  if(panel){
    panel.innerHTML='';
    for(const r of state.rfqs){
      const el=document.createElement('div');
      el.className='item';
      el.innerHTML=`
        <div class="itemTop">
          <div>
            <div class="itemTitle">${escapeHtml(r.empresa)} · ${escapeHtml(r.id)}</div>
            <div class="itemMeta">${escapeHtml(r.fecha)} · ${escapeHtml(r.serie)} · ${escapeHtml(r.email)}</div>
          </div>
          <div class="badge ${badgeFromEstado(r.estado).kind}">${escapeHtml(r.estado)}</div>
        </div>
        <div class="itemBottom">
          <span class="tag">Asunto: ${escapeHtml(short(r.asunto,58))}</span>
          <span class="tag">Ver email</span>
        </div>
      `;
      el.addEventListener('click', ()=>openModal('RFQ (email)', `${r.empresa} · ${r.id}`, renderKV({
        'Empresa':r.empresa,'Fecha':r.fecha,'Serie':r.serie,'Estado':r.estado,'Email':r.email,'Teléfono':r.tel,'Asunto':r.asunto,'Cuerpo':r.cuerpo
      })));
      panel.appendChild(el);
    }
  }
}

function renderAll(){
  const ofertas=filterRows(state.ofertasRaw);
  const pedidos=filterRows(state.pedidosRaw);

  $('#kpiOfertas').textContent = ofertas.length.toLocaleString('es-ES');
  $('#kpiPedidos').textContent = pedidos.length.toLocaleString('es-ES');
  $('#kpiImporteOfertado').textContent = fmtEUR(sum(ofertas, r=>r.totalIva));
  $('#kpiImportePedido').textContent = fmtEUR(sum(pedidos, r=>r.totalIva));


  renderList($('#ofertasList'), ofertas.slice(0,10).map(r=>({
    title:`${r.cliente||'Sin cliente'} · Oferta ${r.numOferta||'—'}`,
    meta:`${r.serie||'—'} · ${fmtDate(r.fecha)} · ${r.comercial||'—'}`,
    badge: badgeFromEstado(r.estado),
    tags:[`Estado: ${r.estado||'—'}`, `Importe: ${fmtEUR(r.totalIva)}`, `Visado: ${r.visado||'—'}`],
    onOpen: ()=>openModal('Oferta', `${r.serie||''} · ${r.numOferta||''}`, renderKV({
      'Serie':r.serie,'Nº Oferta':r.numOferta,'Fecha':fmtDate(r.fecha),'Cliente':r.cliente,'Razón social':r.razon,
      'Comercial':r.comercial,'Estado':r.estado,'Visado':r.visado,'Total IVA':fmtEUR(r.totalIva),'Id Oferta':r.idOferta,'Observaciones':r.obs
    }))
  })));

  renderList($('#pedidosList'), pedidos.slice(0,10).map(r=>({
    title:`${r.cliente||'Sin cliente'} · Pedido ${r.numPedido||'—'}`,
    meta:`ID ${r.idPedido||'—'} · ${r.serie||'—'} · ${fmtDate(r.fecha)}`,
    badge: badgeFromEstado(r.estado),
    tags:[`Estado: ${r.estado||'—'}`, `Importe: ${fmtEUR(r.totalIva)}`, r.razon?`Razón: ${short(r.razon,34)}`:'Razón: —'],
    onOpen: ()=>openModal('Pedido', `${r.serie||''} · ${r.numPedido||''}`, renderKV({
      'Id Pedido':r.idPedido,'Serie':r.serie,'Nº Pedido':r.numPedido,'Fecha':fmtDate(r.fecha),'Cliente':r.cliente,'Id Cliente':r.idCliente,
      'Razón social':r.razon,'Descripción':r.desc,'Estado':r.estado,'Total IVA':fmtEUR(r.totalIva),'Observaciones':r.obs
    }))
  })));

  const ofAcept=countWhere(ofertas, r=>/acept/i.test(r.estado||''));
  const ofRech=countWhere(ofertas, r=>/rech/i.test(r.estado||''));
  const ofEnv=countWhere(ofertas, r=>/envi/i.test(r.estado||''));
  $('#ofK1').textContent=ofEnv; $('#ofK2').textContent=ofAcept; $('#ofK3').textContent=ofRech; $('#ofK4').textContent=fmtEUR(sum(ofertas,r=>r.totalIva));

  const peEnCurso=countWhere(pedidos, r=>/curso|prepar|produ/i.test(r.estado||''));
  const pePend=countWhere(pedidos, r=>/pend/i.test(r.estado||''));
  const peFin=countWhere(pedidos, r=>/final|complet/i.test(r.estado||''));
  $('#peK1').textContent=peEnCurso; $('#peK2').textContent=pePend; $('#peK3').textContent=peFin; $('#peK4').textContent=fmtEUR(sum(pedidos,r=>r.totalIva));

  renderSparks($('#ofertasSparks'), ofertas, 'oferta');
  renderSparks($('#pedidosSparks'), pedidos, 'pedido');
  renderSparks($('#rfqSparks'), state.rfqs, 'rfq');

  renderTables(ofertas, pedidos);
  renderRFQs();
}

function setView(name){
  $$('.pill').forEach(p=>p.classList.toggle('active', p.dataset.view===name));
  $('#view-home').classList.toggle('hidden', name!=='home');
  $('#view-ofertas').classList.toggle('hidden', name!=='ofertas');
  $('#view-pedidos').classList.toggle('hidden', name!=='pedidos');
  $('#view-rfqs').classList.toggle('hidden', name!=='rfqs');
}

function exportCSV(rows, fileName){
  if(!rows.length){ alert('No hay datos para exportar'); return; }
  const cols=Object.keys(rows[0]);
  const lines=[cols.join(';')].concat(rows.map(r=>cols.map(c=>{
    const v=r[c]??''; const s=String(v).replace(/\r?\n/g,' ').trim();
    return s.includes(';')||s.includes('"') ? '"'+s.replace(/"/g,'""')+'"' : s;
  }).join(';')));
  const blob=new Blob([lines.join('\n')], {type:'text/csv;charset=utf-8'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=fileName; a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href), 1000);
}

function loadOfertasFromCSV(text){
  const {cols,rows}=parseCSV(text);
  const idx=pickCol(mapOfertas, cols);
  state.ofertasRaw=rows.map(r=>({
    serie:r[idx.serie]??'',
    numOferta:r[idx.numOferta]??'',
    fecha:r[idx.fecha]??'',
    idCliente:r[idx.idCliente]??'',
    cliente:r[idx.cliente]??'',
    razon:r[idx.razon]??'',
    comercial:r[idx.comercial]??'',
    estado:r[idx.estado]??'',
    visado:r[idx.visado]??'',
    obs:r[idx.obs]??'',
    totalIva:toNumber(r[idx.totalIva]),
    idOferta:r[idx.idOferta]??''
  }));
  rebuildFilterOptions();
  renderAll();
}
function loadPedidosFromCSV(text){
  const {cols,rows}=parseCSV(text);
  const idx=pickCol(mapPedidos, cols);
  state.pedidosRaw=rows.map(r=>({
    idPedido:r[idx.idPedido]??'',
    serie:r[idx.serie]??'',
    numPedido:r[idx.numPedido]??'',
    fecha:r[idx.fecha]??'',
    cliente:r[idx.cliente]??'',
    idCliente:r[idx.idCliente]??'',
    razon:r[idx.razon]??'',
    desc:r[idx.desc]??'',
    estado:r[idx.estado]??'',
    totalIva:toNumber(r[idx.totalIva]),
    obs:r[idx.obs]??'',
    comercial:''
  }));
  rebuildFilterOptions();
  renderAll();
}

function sampleOfertasCSV(){
  return `Serie;NumOferta;Fecha;Id Cliente;Cliente;Razón Social;Comercial;EstadoDescrp;Visado;Observaciones;TotalIVA;Id Oferta
FV;250009;10/09/2025 13:33;430005993;CARAMELOS Y CHOCOLATES;MAS QUE UN CARAMELO C&CH, S.L.;JUAN MANUEL RIEGO;Aceptada;VERDADERO;"170 LATAS ...";0;57336
FN;250530;10/09/2025 15:15;430033653;SUPERMERCADOS LLOBET SA;SUPERMERCADOS LLOBET SA;Supervisor InnProRes;Generada;FALSO;"100 UNIDADES ...";4664,55;57338
FN;250533;11/09/2025 0:00;430003233;REPSOL S.A;REPSOL S.A.;JUANA ROMERO;Aceptada;FALSO;"307.200 UDS ...";20342,78;57341
`;
}
function samplePedidosCSV(){
  return `Id Pedido;Serie;NúmeroPedido;Observaciones;Descripción Pedido;Estado;Fecha;Cliente;Id Cliente;Razón Social;TotalIVA
71603;FH;250627;"ENTREGA ...";CAJITAS CUBO HOTEL SANT FRANCESC;COMPLETADO;18/07/2025 0:00;HOTEL SANT FRANCESC;430009164;SANT FRANCESC HOTEL SINGULAR;1633,5
71604;FH;250628;"PLAZO ...";NAPOLITANAS SABORES PREMIUM SANT FRANCESC.;COMPLETADO;18/07/2025 0:00;HOTEL SANT FRANCESC;430009164;SANT FRANCESC HOTEL SINGULAR;1585,1
71610;FN;250476;"DIRECCIÓN POR CONFIRMAR";SACHET CON BOLSITA DE TÉ (RELAX);COMPLETADO;21/07/2025 0:00;Monterreina Comunicación s.l.u;430033216;Monterreina Comunicación s.l.u;296,45
`;
}

function seedRFQs(){
  state.rfqs=[
    {id:'RFQ-1',empresa:'Alfa Retail',email:'compras@alfa.com',tel:'+34 600 111 222',serie:'Nacional FN',estado:'Por contestar',fecha:'2025-10-02',asunto:'Bolsas 10.000 uds',cuerpo:'Necesito oferta para bolsas personalizadas.'},
    {id:'RFQ-2',empresa:'Bravo Foods',email:'compras@bravo.com',tel:'+34 600 222 333',serie:'Export EA',estado:'Propuesta en curso',fecha:'2025-10-05',asunto:'Cajas microcanal 5.000 uds',cuerpo:'Envío a Valencia. ¿Incluye troquel?'},
    {id:'RFQ-3',empresa:'Hotel Mar Azul',email:'compras@marazul.com',tel:'',serie:'Hoteles',estado:'Contestada',fecha:'2025-10-06',asunto:'Amenities · packaging',cuerpo:'Estamos valorando amenities para temporada alta.'}
  ];
}

function bindEvents(){
  $$('.pill[data-view]').forEach(p=>p.addEventListener('click',()=>setView(p.dataset.view)));
  $$('[data-open-panel]').forEach(b=>b.addEventListener('click',(e)=>{e.preventDefault(); setView(b.dataset.openPanel); window.scrollTo({top:0,behavior:'smooth'});}));

  $('#modal').addEventListener('click',(e)=>{ if(e.target?.dataset?.close) closeModal(); });
  document.addEventListener('keydown',(e)=>{ if(e.key==='Escape') closeModal(); });

  $('#filterSerie').addEventListener('change',e=>{state.filters.serie=e.target.value; renderAll();});
  $('#filterComercial').addEventListener('change',e=>{state.filters.comercial=e.target.value; renderAll();});
  $('#filterDesde').addEventListener('change',e=>{state.filters.desde=e.target.value; renderAll();});
  $('#filterHasta').addEventListener('change',e=>{state.filters.hasta=e.target.value; renderAll();});
  $('#filterQuery').addEventListener('input',e=>{state.filters.q=e.target.value; renderAll();});

  $('#btnReset').addEventListener('click',()=>{
    state.filters={serie:'',comercial:'',desde:'',hasta:'',q:''};
    $('#filterSerie').value=''; $('#filterComercial').value=''; $('#filterDesde').value=''; $('#filterHasta').value=''; $('#filterQuery').value='';
    renderAll();
  });

  $('#fileOfertas').addEventListener('change', async (e)=>{ const f=e.target.files?.[0]; if(!f) return; loadOfertasFromCSV(await f.text()); });
  $('#filePedidos').addEventListener('change', async (e)=>{ const f=e.target.files?.[0]; if(!f) return; loadPedidosFromCSV(await f.text()); });

  $('#btnSampleOfertas').addEventListener('click',()=>loadOfertasFromCSV(sampleOfertasCSV()));
  $('#btnSamplePedidos').addEventListener('click',()=>loadPedidosFromCSV(samplePedidosCSV()));

  $('#btnExportOfertas').addEventListener('click',()=>exportCSV(filterRows(state.ofertasRaw),'ofertas_filtradas.csv'));
  $('#btnExportPedidos').addEventListener('click',()=>exportCSV(filterRows(state.pedidosRaw),'pedidos_filtrados.csv'));
  $('#btnExportOfertas2').addEventListener('click',()=>exportCSV(filterRows(state.ofertasRaw),'ofertas_filtradas.csv'));
  $('#btnExportPedidos2').addEventListener('click',()=>exportCSV(filterRows(state.pedidosRaw),'pedidos_filtrados.csv'));

  $('#btnAyuda').addEventListener('click',()=>openModal('Ayuda CSV','Columnas esperadas (mapeo tolerante)',renderKV({
    'Ofertas':'Serie, NumOferta, Fecha, Id Cliente, Cliente, Razón Social, Comercial, EstadoDescrp, Visado, Observaciones, TotalIVA, Id Oferta',
    'Pedidos':'Id Pedido, Serie, NúmeroPedido, Fecha, Cliente, Id Cliente, Razón Social, Descripción Pedido, Estado, TotalIVA, Observaciones'
  })));

  $('#btnAddFakeRFQ').addEventListener('click',()=>{
    const n=state.rfqs.length+1;
    state.rfqs.unshift({id:`RFQ-${n}`,empresa:`Empresa Demo ${n}`,email:`demo${n}@empresa.com`,tel:'',serie:['Nacional FN','Export EA','Hoteles'][n%3],estado:['Por contestar','Propuesta en curso','Contestada'][n%3],fecha:new Date().toISOString().slice(0,10),asunto:`RFQ demo ${n}`,cuerpo:'Texto demo.'});
    renderAll();
  });

  $('#btnTestRFQ').addEventListener('click',()=>{
    openModal('Test RFQ','Simulación rápida',renderKV({'Acción':'Abre RFQs y valida lectura tipo email','Siguiente':'Tras validar v45, conectamos IMAP real.'}));
    setTimeout(()=>setView('rfqs'),150);
  });
}

function init(){
  initTheme();
  seedRFQs();
  bindEvents();
  renderAll();
  setView('home');
}
init();
